

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class search extends Application{
    private String SQLaccess = "root";
    private String SQLpassword = "7M14ebr5Po";
    public void setSQLpassword(String string){this.SQLpassword = string;}
    public void setSQLaccess(String string){this.SQLaccess = string;}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub
		Stage getStunumorName = new Stage();

		BorderPane mainPane = new BorderPane();
        mainPane.setPadding(new Insets(25, 25, 25, 25));
        

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(25, 25, 25,25 ));
        grid.setVgap(5);
        grid.setHgap(5);
        grid.setAlignment(Pos.CENTER);

        Scene sceneMain = new Scene(mainPane,900, 500);
        
        Label labeltitle = new Label("��ѯ");
	    labeltitle.setAlignment(Pos.CENTER);
	    labeltitle.setTextFill(Color.valueOf("#62a8ea"));
	    labeltitle.setStyle("-fx-font-weight: bold");
	    labeltitle.setFont(new Font(30));
	    
	    HBox hbox = new HBox();
	    hbox.setPadding(new Insets(25, 25, 25, 25));
	    hbox.setAlignment(Pos.CENTER);
	    hbox.getChildren().addAll(labeltitle);
	     
        MenuBar menuBar = new MenuBar();
        
        Menu menudepart = new Menu("ϵ��");

        Menu menuclass = new Menu("�༶");
        
        Menu menunumber = new Menu("ѧ��");

        MenuItem itemGetNumber = new MenuItem("����������ѧ�š�");

        itemGetNumber.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                BorderPane bpgetNum = new BorderPane();
                bpgetNum.setPadding(new Insets(25, 25, 25, 25));

                HBox hboxInputsets = new HBox();
                HBox hboxBtnsets = new HBox();
                hboxInputsets.setAlignment(Pos.CENTER);
                hboxBtnsets.setAlignment(Pos.CENTER);
                hboxInputsets.setSpacing(10);
                hboxBtnsets.setSpacing(15);

                TextField textgetNum = new TextField();
                textgetNum.setStyle("{-fx-text-fill:#cccccc;-fx-font-size:20;}");
                textgetNum.setText("������ѧ��");
                textgetNum.setOpacity(0.5);
                textgetNum.setPrefSize(500, 40);
                hboxInputsets.getChildren().addAll(textgetNum);

                Button btnConfirm = new Button("����");
                btnConfirm.setStyle("{-fx-font-size:20;  -fx-background-color:#62a8ea; -fx-text-fill:white; -fx-font-size:15;}");
                btnConfirm.setPrefWidth(100.0);
                btnConfirm.setPrefHeight(20.0);
                Button btnCancel = new Button("����");
                btnCancel.setStyle("{-fx-font-size:20;  -fx-background-color:#62a8ea; -fx-text-fill:white; -fx-font-size:15;}");
                btnCancel.setPrefWidth(100.0);
                btnCancel.setPrefHeight(20.0);
                
                ScrollPane sp = new ScrollPane();
                
                btnConfirm.setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {
                        try {
                            SQLdormitory sqlsercher = new SQLdormitory();
                            sqlsercher.setSQLPassword(SQLpassword);
                            sqlsercher.setSQLAccess(SQLaccess);
                            String[][] info = sqlsercher.getInformation("stuId", textgetNum.getText());
                            getStunumorName.close();
                            HBox hboxInfo = new HBox();

                            Label labelname = new Label(info[0][0]);
                            labelname.setAlignment(Pos.CENTER_LEFT);
                    	    labelname.setTextFill(Color.valueOf("#62a8ea"));
                    	    labelname.setStyle("-fx-font-weight: bold");
                    	    labelname.setFont(new Font(20));
                            Label labelnum = new Label(info[0][1]);
                            labelname.setAlignment(Pos.CENTER_LEFT);
                    	    labelname.setTextFill(Color.valueOf("#62a8ea"));
                    	    labelname.setStyle("-fx-font-weight: bold");
                    	    labelname.setFont(new Font(20));
                            if(info[0][2].equals("1")){
                                String[] roominfo = sqlsercher.getRoomNumber(info[0][0]);
                                Label labelroomnum = new Label("����ס" + roominfo[0]);
                                labelroomnum.setAlignment(Pos.CENTER_LEFT);
                        	    labelroomnum.setTextFill(Color.valueOf("#62a8ea"));
                        	    labelroomnum.setStyle("-fx-font-weight: bold");
                        	    labelroomnum.setFont(new Font(20));
                                Label labelbednum = new Label("��λ" + roominfo[1]);
                                labelbednum.setAlignment(Pos.CENTER_LEFT);
                        	    labelbednum.setTextFill(Color.valueOf("#62a8ea"));
                        	    labelbednum.setStyle("-fx-font-weight: bold");
                        	    labelbednum.setFont(new Font(20));
                                hboxInfo.getChildren().addAll(labelname, labelnum, labelroomnum, labelbednum);
                            }
                            else{
                                Label labelUnsigned = new Label("δ��ס");
                                labelUnsigned.setAlignment(Pos.CENTER_LEFT);
                        	    labelUnsigned.setTextFill(Color.valueOf("#62a8ea"));
                        	    labelUnsigned.setStyle("-fx-font-weight: bold");
                        	    labelUnsigned.setFont(new Font(20));
                                hboxInfo.getChildren().addAll(labelname, labelnum, labelUnsigned);
                            }

                            sp.setContent(hboxInfo);
                            mainPane.setCenter(sp);
                        }
                        catch (Exception e){
                            showMessage("δ��ѯ����Ϣ�����ݿ������");

                        }
                    }

                });

                btnCancel.setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {
                        getStunumorName.close();
                    }
                });
                
                hboxBtnsets.getChildren().addAll(btnConfirm, btnCancel);
                hboxBtnsets.setSpacing(50);
                bpgetNum.setCenter(hboxInputsets);
                bpgetNum.setBottom(hboxBtnsets);
                
                Scene scenegetNum = new Scene(bpgetNum, 400, 150);
                getStunumorName.setScene(scenegetNum);
                getStunumorName.setTitle("������ѧ��");
                getStunumorName.show();
            }
        });
        
        menunumber.getItems().add(itemGetNumber);
        
        Menu menuname = new Menu("����");
        MenuItem itemGetname = new MenuItem("����������������");

        itemGetname.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                BorderPane bpgetNum = new BorderPane();
                bpgetNum.setPadding(new Insets(25, 25, 25, 25));

                HBox hboxInputsets = new HBox();
                HBox hboxBtnsets = new HBox();
                hboxInputsets.setAlignment(Pos.CENTER);
                hboxBtnsets.setAlignment(Pos.CENTER);
                hboxInputsets.setSpacing(10);
                hboxBtnsets.setSpacing(15);

                TextField textgetNum = new TextField();
                textgetNum.setStyle("{-fx-text-fill:#cccccc;-fx-font-size:20;}");
                textgetNum.setText("����������");
                textgetNum.setOpacity(0.5);
                textgetNum.setPrefSize(500, 40);
                hboxInputsets.getChildren().addAll(textgetNum);

                Button btnConfirm = new Button("����");
                btnConfirm.setStyle("{-fx-font-size:20;  -fx-background-color:#62a8ea; -fx-text-fill:white; -fx-font-size:15;}");
                btnConfirm.setPrefWidth(100.0);
                btnConfirm.setPrefHeight(20.0);
                Button btnCancel = new Button("����");
                btnCancel.setStyle("{-fx-font-size:20;  -fx-background-color:#62a8ea; -fx-text-fill:white; -fx-font-size:15;}");
                btnCancel.setPrefWidth(100.0);
                btnCancel.setPrefHeight(20.0);
                
                ScrollPane sp = new ScrollPane();
                btnConfirm.setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {
                        try {
                            SQLdormitory sqlsercher = new SQLdormitory();
                            String[][] info = sqlsercher.getInformation("stuName", textgetNum.getText());
                            getStunumorName.close();
                            HBox hboxInfo = new HBox();

                            Label labelname = new Label(info[0][0]);
                            labelname.setAlignment(Pos.CENTER_LEFT);
                    	    labelname.setTextFill(Color.valueOf("#62a8ea"));
                    	    labelname.setStyle("-fx-font-weight: bold");
                    	    labelname.setFont(new Font(20));
                            Label labelnum = new Label(info[0][1]);
                            labelnum.setAlignment(Pos.CENTER_LEFT);
                    	    labelnum.setTextFill(Color.valueOf("#62a8ea"));
                    	    labelnum.setStyle("-fx-font-weight: bold");
                    	    labelnum.setFont(new Font(20));
                            if(info[0][2].equals("1")){
                                String[] roominfo = sqlsercher.getRoomNumber(info[0][0]);
                                Label labelroomnum = new Label("����ס" + roominfo[0]);
                                labelroomnum.setAlignment(Pos.CENTER_LEFT);
                        	    labelroomnum.setTextFill(Color.valueOf("#62a8ea"));
                        	    labelroomnum.setStyle("-fx-font-weight: bold");
                        	    labelroomnum.setFont(new Font(20));
                                Label labelbednum = new Label("��λ" + roominfo[1]);
                                labelbednum.setAlignment(Pos.CENTER_LEFT);
                        	    labelbednum.setTextFill(Color.valueOf("#62a8ea"));
                        	    labelbednum.setStyle("-fx-font-weight: bold");
                        	    labelbednum.setFont(new Font(20));
                                hboxInfo.getChildren().addAll(labelname, labelnum, labelroomnum, labelbednum);
                            }
                            else{
                                Label labelUnsigned = new Label("δ��ס");
                                hboxInfo.getChildren().addAll(labelname, labelnum, labelUnsigned);
                            }

                            sp.setContent(hboxInfo);
                            mainPane.setCenter(sp);
                        }
                        catch (Exception e){
                            showMessage("δ��ѯ����Ϣ�����ݿ������");

                        }
                    }

                });

                btnCancel.setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {
                        getStunumorName.close();
                    }
                });
                hboxBtnsets.getChildren().addAll(btnConfirm, btnCancel);
                hboxBtnsets.setSpacing(50);
                bpgetNum.setCenter(hboxInputsets);
                bpgetNum.setBottom(hboxBtnsets);

                Scene scenegetNum = new Scene(bpgetNum, 400, 150);
                getStunumorName.setScene(scenegetNum);
                getStunumorName.setTitle("����������");
                getStunumorName.show();
            }
        });
        menuname.getItems().add(itemGetname);
        
        Menu menudormitory = new Menu("����");
        
        menuBar.getMenus().addAll(menudepart,menuclass,menunumber,menuname,menudormitory);
        menuBar.setStyle("{-fx-font-size:20;  -fx-background-color:#62a8ea; -fx-font-size:15;}");
      
        VBox vbox = new VBox();
        vbox.setSpacing(5);
        vbox.getChildren().addAll(labeltitle,menuBar);

        SQLdormitory sqlsearcher = new SQLdormitory();
        
        MenuItem biochemistry = new MenuItem("���ﻯѧ");
        biochemistry.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                        ScrollPane sp = new ScrollPane();
                        sp.setPadding(new Insets(25, 25, 25, 25));

                        VBox vboxsets = new VBox();
                        vboxsets.setSpacing(10);
                        vboxsets.setAlignment(Pos.TOP_LEFT);

                        VBox vboxSigned = new VBox();
                        vboxSigned.setSpacing(10);
                        vboxSigned.setAlignment(Pos.TOP_LEFT);

                        VBox vboxUnsigned = new VBox();
                        vboxUnsigned.setSpacing(10);
                        vboxUnsigned.setAlignment(Pos.TOP_LEFT);

                        Label labelTitle = new Label("���ﻯѧ");
                        labelTitle.setTextFill(Color.valueOf("#62a8ea"));
                        labelTitle.setStyle("-fx-font-weight: bold;");
                        labelTitle.setFont(new Font(20));
                        Label labelSigned = new Label("����ס");
                        labelSigned.setTextFill(Color.valueOf("#62a8ea"));
                        labelSigned.setStyle("-fx-font-weight: bold;");
                        labelSigned.setFont(new Font(20));
                        
                        Label labelUnsigned = new Label("δ��ס");
                        labelUnsigned.setTextFill(Color.valueOf("#62a8ea"));
                        labelUnsigned.setStyle("-fx-font-weight: bold;");
                        labelUnsigned.setFont(new Font(20));
                        
                        vboxsets.getChildren().add(labelTitle);
                        vboxSigned.getChildren().add(labelSigned);
                        vboxUnsigned.getChildren().add(labelUnsigned);

                        String[][] result = sqlsearcher.getInformation("department", "���ﻯѧ");
                        Label[] labelSignedex = new Label[4 * result.length];
                        Label[] labelUnsignedex = new Label[2 * result.length];
                        HBox[] hbrowsets = new HBox[result.length];
                        for(int i = 0; i < result.length; i++) {
                                if(result[i][2].equals("1")){
                                        hbrowsets[i] = new HBox();
                                        hbrowsets[i].setSpacing(2);
                                        hbrowsets[i].setAlignment(Pos.CENTER_LEFT);

                                        String[] roominfo = sqlsearcher.getRoomNumber(result[i][0]);

                                        labelSignedex[i * 4] = new Label(result[i][0]);
                                    labelSignedex[i * 4].setTextFill(Color.valueOf("#62a8ea"));
                                    labelSignedex[i * 4].setStyle("-fx-font-weight: bold;");
                                    labelSignedex[i * 4].setFont(new Font(20));
                                        labelSignedex[i * 4 + 1] = new Label(result[i][1]);
                                        labelSignedex[i * 4 + 1].setTextFill(Color.valueOf("#62a8ea"));
                                        labelSignedex[i * 4 + 1].setStyle("-fx-font-weight: bold;");
                                        labelSignedex[i * 4 + 1].setFont(new Font(20));
                                        labelSignedex[i * 4 + 2] = new Label("����ס" + roominfo[0]);
                                        labelSignedex[i * 4 + 2].setTextFill(Color.valueOf("#62a8ea"));
                                        labelSignedex[i * 4 + 2].setStyle("-fx-font-weight: bold;");
                                        labelSignedex[i * 4 + 2].setFont(new Font(20));
                                        labelSignedex[i * 4 + 3] = new Label("��λ" + roominfo[1]);
                                        labelSignedex[i * 4 + 3].setTextFill(Color.valueOf("#62a8ea"));
                                        labelSignedex[i * 4 + 3].setStyle("-fx-font-weight: bold;");
                                        labelSignedex[i * 4 + 3].setFont(new Font(20));
                                        hbrowsets[i].getChildren().addAll(labelSignedex[i * 4], labelSignedex[i * 4 + 1], labelSignedex[i * 4 + 2], labelSignedex[i * 4 + 3]);
                                        vboxSigned.getChildren().add(hbrowsets[i]);
                                }
                                else{
                                        hbrowsets[i] = new HBox();
                                        hbrowsets[i].setSpacing(2);
                                        hbrowsets[i].setAlignment(Pos.CENTER_LEFT);

                                        labelUnsignedex[i * 2] = new Label(result[i][0]);
                                        labelUnsignedex[i * 2].setTextFill(Color.valueOf("#62a8ea"));
                                        labelUnsignedex[i * 2].setStyle("-fx-font-weight: bold;");
                                        labelUnsignedex[i * 2].setFont(new Font(20));
                                        labelUnsignedex[i * 2 + 1] = new Label(result[i][1]);
                                        labelUnsignedex[i * 2 + 1].setTextFill(Color.valueOf("#62a8ea"));
                                        labelUnsignedex[i * 2 + 1].setStyle("-fx-font-weight: bold;");
                                        labelUnsignedex[i * 2 + 1].setFont(new Font(20));
                                        hbrowsets[i].getChildren().addAll(labelUnsignedex[i * 2], labelUnsignedex[i * 2 + 1]);
                                        vboxUnsigned.getChildren().add(hbrowsets[i]);
                                }
                        }
                        vboxsets.getChildren().addAll(vboxSigned, vboxUnsigned);
                        sp.setContent(vboxsets);
                        mainPane.setCenter(sp);
                }
        });
        
        MenuItem biomedicine = new MenuItem("����ҽѧ");
        biomedicine.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                ScrollPane sp = new ScrollPane();
                sp.setPadding(new Insets(25, 25, 25, 25));

                VBox vboxsets = new VBox();
                vboxsets.setSpacing(10);
                vboxsets.setAlignment(Pos.TOP_LEFT);

                VBox vboxSigned = new VBox();
                vboxSigned.setSpacing(10);
                vboxSigned.setAlignment(Pos.TOP_LEFT);

                VBox vboxUnsigned = new VBox();
                vboxUnsigned.setSpacing(10);
                vboxUnsigned.setAlignment(Pos.TOP_LEFT);

                Label labelTitle = new Label("����ҽѧ");
                labelTitle.setTextFill(Color.valueOf("#62a8ea"));
                labelTitle.setStyle("-fx-font-weight: bold;");
                labelTitle.setFont(new Font(20));
                
                Label labelSigned = new Label("����ס");
                labelSigned.setTextFill(Color.valueOf("#62a8ea"));
                labelSigned.setStyle("-fx-font-weight: bold;");
                labelSigned.setFont(new Font(20));
                Label labelUnsigned = new Label("δ��ס");
                labelUnsigned.setTextFill(Color.valueOf("#62a8ea"));
                labelUnsigned.setStyle("-fx-font-weight: bold;");
                labelUnsigned.setFont(new Font(20));

                vboxsets.getChildren().add(labelTitle);
                vboxSigned.getChildren().add(labelSigned);
                vboxUnsigned.getChildren().add(labelUnsigned);

                String[][] result = sqlsearcher.getInformation("department", "����ҽѧ");
                Label[] labelSignedex = new Label[4 * result.length];
                Label[] labelUnsignedex = new Label[2 * result.length];
                HBox[] hbrowsets = new HBox[result.length];
                for(int i = 0; i < result.length; i++) {
                    if(result[i][2].equals("1")){
                        hbrowsets[i] = new HBox();
                        hbrowsets[i].setSpacing(2);
                        hbrowsets[i].setAlignment(Pos.CENTER_LEFT);

                        String[] roominfo = sqlsearcher.getRoomNumber(result[i][0]);

                        labelSignedex[i * 4] = new Label(result[i][0]);
                        labelSignedex[i * 4].setTextFill(Color.valueOf("#62a8ea"));
                        labelSignedex[i * 4].setStyle("-fx-font-weight: bold;");
                        labelSignedex[i * 4].setFont(new Font(20));
                        labelSignedex[i * 4 + 1] = new Label(result[i][1]);
                        labelSignedex[i * 4 + 1].setTextFill(Color.valueOf("#62a8ea"));
                        labelSignedex[i * 4 + 1].setStyle("-fx-font-weight: bold;");
                        labelSignedex[i * 4 + 1].setFont(new Font(20));
                        labelSignedex[i * 4 + 2] = new Label("����ס" + roominfo[0]);
                        labelSignedex[i * 4 + 2].setTextFill(Color.valueOf("#62a8ea"));
                        labelSignedex[i * 4 + 2].setStyle("-fx-font-weight: bold;");
                        labelSignedex[i * 4 + 2].setFont(new Font(20));
                        labelSignedex[i * 4 + 3] = new Label("��λ" + roominfo[1]);
                        labelSignedex[i * 4 + 3].setTextFill(Color.valueOf("#62a8ea"));
                        labelSignedex[i * 4 + 3].setStyle("-fx-font-weight: bold;");
                        labelSignedex[i * 4 + 3].setFont(new Font(20));
                        hbrowsets[i].getChildren().addAll(labelSignedex[i * 4], labelSignedex[i * 4 + 1], labelSignedex[i * 4 + 2], labelSignedex[i * 4 + 3]);
                        vboxSigned.getChildren().add(hbrowsets[i]);
                    }
                    else{
                        hbrowsets[i] = new HBox();
                        hbrowsets[i].setSpacing(2);
                        hbrowsets[i].setAlignment(Pos.CENTER_LEFT);

                        labelUnsignedex[i * 2] = new Label(result[i][0]);
                        labelUnsignedex[i * 2].setTextFill(Color.valueOf("#62a8ea"));
                        labelUnsignedex[i * 2].setStyle("-fx-font-weight: bold;");
                        labelUnsignedex[i * 2].setFont(new Font(20));
                        labelUnsignedex[i * 2 + 1] = new Label(result[i][1]);
                        labelUnsignedex[i * 2 + 1].setTextFill(Color.valueOf("#62a8ea"));
                        labelUnsignedex[i * 2 + 1].setStyle("-fx-font-weight: bold;");
                        labelUnsignedex[i * 2 + 1].setFont(new Font(20));
                        hbrowsets[i].getChildren().addAll(labelUnsignedex[i * 2], labelUnsignedex[i * 2 + 1]);
                        vboxUnsigned.getChildren().add(hbrowsets[i]);
                    }
                }
                vboxsets.getChildren().addAll(vboxSigned, vboxUnsigned);
                sp.setContent(vboxsets);
                mainPane.setCenter(sp);
            }
        });
        
        MenuItem healthcontrol = new MenuItem("��������");
        healthcontrol.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                ScrollPane sp = new ScrollPane();
                sp.setPadding(new Insets(25, 25, 25, 25));

                VBox vboxsets = new VBox();
                vboxsets.setSpacing(10);
                vboxsets.setAlignment(Pos.TOP_LEFT);

                VBox vboxSigned = new VBox();
                vboxSigned.setSpacing(10);
                vboxSigned.setAlignment(Pos.TOP_LEFT);

                VBox vboxUnsigned = new VBox();
                vboxUnsigned.setSpacing(10);
                vboxUnsigned.setAlignment(Pos.TOP_LEFT);

                Label labelTitle = new Label("��������");
                labelTitle.setTextFill(Color.valueOf("#62a8ea"));
                labelTitle.setStyle("-fx-font-weight: bold;");
                labelTitle.setFont(new Font(20));
                Label labelSigned = new Label("����ס");
                labelSigned.setTextFill(Color.valueOf("#62a8ea"));
                labelSigned.setStyle("-fx-font-weight: bold;");
                labelSigned.setFont(new Font(20));
                Label labelUnsigned = new Label("δ��ס");
                labelUnsigned.setTextFill(Color.valueOf("#62a8ea"));
                labelUnsigned.setStyle("-fx-font-weight: bold;");
                labelUnsigned.setFont(new Font(20));

                vboxsets.getChildren().add(labelTitle);
                vboxSigned.getChildren().add(labelSigned);
                vboxUnsigned.getChildren().add(labelUnsigned);

                String[][] result = sqlsearcher.getInformation("department", "��������");
                Label[] labelSignedex = new Label[4 * result.length];
                Label[] labelUnsignedex = new Label[2 * result.length];
                HBox[] hbrowsets = new HBox[result.length];
                for(int i = 0; i < result.length; i++) {
                    if(result[i][2].equals("1")){
                        hbrowsets[i] = new HBox();
                        hbrowsets[i].setSpacing(2);
                        hbrowsets[i].setAlignment(Pos.CENTER_LEFT);

                        String[] roominfo = sqlsearcher.getRoomNumber(result[i][0]);

                        labelSignedex[i * 4] = new Label(result[i][0]);
                        labelSignedex[i * 4].setTextFill(Color.valueOf("#62a8ea"));
                        labelSignedex[i * 4].setStyle("-fx-font-weight: bold;");
                        labelSignedex[i * 4].setFont(new Font(20));

                        labelSignedex[i * 4 + 1] = new Label(result[i][1]);
                        labelSignedex[i * 4 + 1].setTextFill(Color.valueOf("#62a8ea"));
                        labelSignedex[i * 4 + 1].setStyle("-fx-font-weight: bold;");
                        labelSignedex[i * 4 + 1].setFont(new Font(20));
                        labelSignedex[i * 4 + 2] = new Label("����ס" + roominfo[0]);
                        labelSignedex[i * 4 + 2].setTextFill(Color.valueOf("#62a8ea"));
                        labelSignedex[i * 4 + 2].setStyle("-fx-font-weight: bold;");
                        labelSignedex[i * 4 + 2].setFont(new Font(20));
                        labelSignedex[i * 4 + 3] = new Label("��λ" + roominfo[1]);
                        labelSignedex[i * 4 + 3].setTextFill(Color.valueOf("#62a8ea"));
                        labelSignedex[i * 4 + 3].setStyle("-fx-font-weight: bold;");
                        labelSignedex[i * 4 + 3].setFont(new Font(20));
                        hbrowsets[i].getChildren().addAll(labelSignedex[i * 4], labelSignedex[i * 4 + 1], labelSignedex[i * 4 + 2], labelSignedex[i * 4 + 3]);
                        vboxSigned.getChildren().add(hbrowsets[i]);
                    }
                    else{
                        hbrowsets[i] = new HBox();
                        hbrowsets[i].setSpacing(2);
                        hbrowsets[i].setAlignment(Pos.CENTER_LEFT);

                        labelUnsignedex[i * 2] = new Label(result[i][0]);
                        labelUnsignedex[i * 2].setTextFill(Color.valueOf("#62a8ea"));
                        labelUnsignedex[i * 2].setStyle("-fx-font-weight: bold;");
                        labelUnsignedex[i * 2].setFont(new Font(20));
                        labelUnsignedex[i * 2 + 1] = new Label(result[i][1]);
                        labelUnsignedex[i * 2 + 1].setTextFill(Color.valueOf("#62a8ea"));
                        labelUnsignedex[i * 2 + 1].setStyle("-fx-font-weight: bold;");
                        labelUnsignedex[i * 2 + 1].setFont(new Font(20));
                        hbrowsets[i].getChildren().addAll(labelUnsignedex[i * 2], labelUnsignedex[i * 2 + 1]);
                        vboxUnsigned.getChildren().add(hbrowsets[i]);
                    }
                }
                vboxsets.getChildren().addAll(vboxSigned, vboxUnsigned);
                sp.setContent(vboxsets);
                mainPane.setCenter(sp);
            }
        });
        
        menudepart.getItems().addAll(biochemistry,biomedicine,healthcontrol);
        
        MenuItem class1= new MenuItem("����181");
        class1.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                ScrollPane sp = new ScrollPane();
                sp.setPadding(new Insets(25, 25, 25, 25));

                VBox vboxsets = new VBox();
                vboxsets.setSpacing(10);
                vboxsets.setAlignment(Pos.TOP_LEFT);

                VBox vboxSigned = new VBox();
                vboxSigned.setSpacing(10);
                vboxSigned.setAlignment(Pos.TOP_LEFT);

                VBox vboxUnsigned = new VBox();
                vboxUnsigned.setSpacing(10);
                vboxUnsigned.setAlignment(Pos.TOP_LEFT);

                Label labelTitle = new Label("����181");
                labelTitle.setTextFill(Color.valueOf("#62a8ea"));
                labelTitle.setStyle("-fx-font-weight: bold;");
                labelTitle.setFont(new Font(20));
                
                Label labelSigned = new Label("����ס");
                labelSigned.setTextFill(Color.valueOf("#62a8ea"));
                labelSigned.setStyle("-fx-font-weight: bold;");
                labelSigned.setFont(new Font(20));
                
                Label labelUnsigned = new Label("δ��ס");
                labelUnsigned.setTextFill(Color.valueOf("#62a8ea"));
                labelUnsigned.setStyle("-fx-font-weight: bold;");
                labelUnsigned.setFont(new Font(20));

                vboxsets.getChildren().add(labelTitle);
                vboxSigned.getChildren().add(labelSigned);
                vboxUnsigned.getChildren().add(labelUnsigned);

                String[][] result = sqlsearcher.getInformation("class", "����181");
                Label[] labelSignedex = new Label[4 * result.length];
                Label[] labelUnsignedex = new Label[2 * result.length];
                HBox[] hbrowsets = new HBox[result.length];
                for(int i = 0; i < result.length; i++) {
                    if(result[i][2].equals("1")){
                        hbrowsets[i] = new HBox();
                        hbrowsets[i].setSpacing(2);
                        hbrowsets[i].setAlignment(Pos.CENTER_LEFT);

                        String[] roominfo = sqlsearcher.getRoomNumber(result[i][0]);

                        labelSignedex[i * 4] = new Label(result[i][0]);
                        labelSignedex[i * 4].setTextFill(Color.valueOf("#62a8ea"));
                        labelSignedex[i * 4].setStyle("-fx-font-weight: bold;");
                        labelSignedex[i * 4].setFont(new Font(20));
                        
                        labelSignedex[i * 4 + 1] = new Label(result[i][1]);
                        labelSignedex[i * 4 + 1].setTextFill(Color.valueOf("#62a8ea"));
                        labelSignedex[i * 4 + 1].setStyle("-fx-font-weight: bold;");
                        labelSignedex[i * 4 + 1].setFont(new Font(20));
                        
                        labelSignedex[i * 4 + 2] = new Label("����ס" + roominfo[0]);
                        labelSignedex[i * 4 + 2].setTextFill(Color.valueOf("#62a8ea"));
                        labelSignedex[i * 4 + 2].setStyle("-fx-font-weight: bold;");
                        labelSignedex[i * 4 + 2].setFont(new Font(20));
                        
                        labelSignedex[i * 4 + 3] = new Label("��λ" + roominfo[1]);
                        labelSignedex[i * 4 + 3].setTextFill(Color.valueOf("#62a8ea"));
                        labelSignedex[i * 4 + 3].setStyle("-fx-font-weight: bold;");
                        labelSignedex[i * 4 + 3].setFont(new Font(20));
                        
                        hbrowsets[i].getChildren().addAll(labelSignedex[i * 4], labelSignedex[i * 4 + 1], labelSignedex[i * 4 + 2], labelSignedex[i * 4 + 3]);
                        vboxSigned.getChildren().add(hbrowsets[i]);
                    }
                    else{
                        hbrowsets[i] = new HBox();
                        hbrowsets[i].setSpacing(2);
                        hbrowsets[i].setAlignment(Pos.CENTER_LEFT);

                        labelUnsignedex[i * 2] = new Label(result[i][0]);
                        labelUnsignedex[i * 2].setTextFill(Color.valueOf("#62a8ea"));
                        labelUnsignedex[i * 2].setStyle("-fx-font-weight: bold;");
                        labelUnsignedex[i * 2].setFont(new Font(20));
                        
                        labelUnsignedex[i * 2 + 1] = new Label(result[i][1]);
                        labelUnsignedex[i * 2 + 1].setTextFill(Color.valueOf("#62a8ea"));
                        labelUnsignedex[i * 2 + 1].setStyle("-fx-font-weight: bold;");
                        labelUnsignedex[i * 2 + 1].setFont(new Font(20));
                        hbrowsets[i].getChildren().addAll(labelUnsignedex[i * 2], labelUnsignedex[i * 2 + 1]);
                        vboxUnsigned.getChildren().add(hbrowsets[i]);
                    }
                }
                vboxsets.getChildren().addAll(vboxSigned, vboxUnsigned);
                sp.setContent(vboxsets);
                mainPane.setCenter(sp);
            }
        });
        
        MenuItem class2= new MenuItem("����182");
        class2.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                ScrollPane sp = new ScrollPane();
                sp.setPadding(new Insets(25, 25, 25, 25));

                VBox vboxsets = new VBox();
                vboxsets.setSpacing(10);
                vboxsets.setAlignment(Pos.TOP_LEFT);

                VBox vboxSigned = new VBox();
                vboxSigned.setSpacing(10);
                vboxSigned.setAlignment(Pos.TOP_LEFT);

                VBox vboxUnsigned = new VBox();
                vboxUnsigned.setSpacing(10);
                vboxUnsigned.setAlignment(Pos.TOP_LEFT);

                Label labelTitle = new Label("����182");
                labelTitle.setTextFill(Color.valueOf("#62a8ea"));
                labelTitle.setStyle("-fx-font-weight: bold;");
                labelTitle.setFont(new Font(20));
                
                Label labelSigned = new Label("����ס");
                labelSigned.setTextFill(Color.valueOf("#62a8ea"));
                labelSigned.setStyle("-fx-font-weight: bold;");
                labelSigned.setFont(new Font(20));
                
                Label labelUnsigned = new Label("δ��ס");
                labelUnsigned.setTextFill(Color.valueOf("#62a8ea"));
                labelUnsigned.setStyle("-fx-font-weight: bold;");
                labelUnsigned.setFont(new Font(20));

                vboxsets.getChildren().add(labelTitle);
                vboxSigned.getChildren().add(labelSigned);
                vboxUnsigned.getChildren().add(labelUnsigned);

                String[][] result = sqlsearcher.getInformation("class", "����182");
                Label[] labelSignedex = new Label[4 * result.length];
                Label[] labelUnsignedex = new Label[2 * result.length];
                HBox[] hbrowsets = new HBox[result.length];
                for(int i = 0; i < result.length; i++) {
                    if(result[i][2].equals("1")){
                        hbrowsets[i] = new HBox();
                        hbrowsets[i].setSpacing(2);
                        hbrowsets[i].setAlignment(Pos.CENTER_LEFT);

                        String[] roominfo = sqlsearcher.getRoomNumber(result[i][0]);

                        labelSignedex[i * 4] = new Label(result[i][0]);
                        labelSignedex[i * 4].setTextFill(Color.valueOf("#62a8ea"));
                        labelSignedex[i * 4].setStyle("-fx-font-weight: bold;");
                        labelSignedex[i * 4].setFont(new Font(20));
                        labelSignedex[i * 4 + 1] = new Label(result[i][1]);
                        labelSignedex[i * 4 + 1].setTextFill(Color.valueOf("#62a8ea"));
                        labelSignedex[i * 4 + 1].setStyle("-fx-font-weight: bold;");
                        labelSignedex[i * 4 + 1].setFont(new Font(20));
                        labelSignedex[i * 4 + 2] = new Label("����ס" + roominfo[0]);
                        labelSignedex[i * 4 + 2].setTextFill(Color.valueOf("#62a8ea"));
                        labelSignedex[i * 4 + 2].setStyle("-fx-font-weight: bold;");
                        labelSignedex[i * 4 + 2].setFont(new Font(20));
                        labelSignedex[i * 4 + 3] = new Label("��λ" + roominfo[1]);

                        labelSignedex[i * 4 + 3].setTextFill(Color.valueOf("#62a8ea"));
                        labelSignedex[i * 4 + 3].setStyle("-fx-font-weight: bold;");
                        labelSignedex[i * 4 + 3].setFont(new Font(20));
                        hbrowsets[i].getChildren().addAll(labelSignedex[i * 4], labelSignedex[i * 4 + 1], labelSignedex[i * 4 + 2], labelSignedex[i * 4 + 3]);
                        vboxSigned.getChildren().add(hbrowsets[i]);
                    }
                    else{
                        hbrowsets[i] = new HBox();
                        hbrowsets[i].setSpacing(2);
                        hbrowsets[i].setAlignment(Pos.CENTER_LEFT);

                        labelUnsignedex[i * 2] = new Label(result[i][0]);
                        labelUnsignedex[i * 2].setTextFill(Color.valueOf("#62a8ea"));
                        labelUnsignedex[i * 2].setStyle("-fx-font-weight: bold;");
                        labelUnsignedex[i * 2].setFont(new Font(20));
                        
                        labelUnsignedex[i * 2 + 1] = new Label(result[i][1]);
                        labelUnsignedex[i * 2 + 1].setTextFill(Color.valueOf("#62a8ea"));
                        labelUnsignedex[i * 2 + 1].setStyle("-fx-font-weight: bold;");
                        labelUnsignedex[i * 2 + 1].setFont(new Font(20));
                        hbrowsets[i].getChildren().addAll(labelUnsignedex[i * 2], labelUnsignedex[i * 2 + 1]);
                        vboxUnsigned.getChildren().add(hbrowsets[i]);
                    }
                }
                vboxsets.getChildren().addAll(vboxSigned, vboxUnsigned);
                sp.setContent(vboxsets);
                mainPane.setCenter(sp);
            }
        });
        
        MenuItem class3= new MenuItem("��ҽ181");
        class3.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                ScrollPane sp = new ScrollPane();
                sp.setPadding(new Insets(25, 25, 25, 25));

                VBox vboxsets = new VBox();
                vboxsets.setSpacing(10);
                vboxsets.setAlignment(Pos.TOP_LEFT);

                VBox vboxSigned = new VBox();
                vboxSigned.setSpacing(10);
                vboxSigned.setAlignment(Pos.TOP_LEFT);

                VBox vboxUnsigned = new VBox();
                vboxUnsigned.setSpacing(10);
                vboxUnsigned.setAlignment(Pos.TOP_LEFT);

                Label labelTitle = new Label("����183");
                labelTitle.setTextFill(Color.valueOf("#62a8ea"));
                labelTitle.setStyle("-fx-font-weight: bold;");
                labelTitle.setFont(new Font(20));
                Label labelSigned = new Label("����ס");
                labelSigned.setTextFill(Color.valueOf("#62a8ea"));
                labelSigned.setStyle("-fx-font-weight: bold;");
                labelSigned.setFont(new Font(20));
                Label labelUnsigned = new Label("δ��ס");
                labelUnsigned.setTextFill(Color.valueOf("#62a8ea"));
                labelUnsigned.setStyle("-fx-font-weight: bold;");
                labelUnsigned.setFont(new Font(20));
                vboxsets.getChildren().add(labelTitle);
                vboxSigned.getChildren().add(labelSigned);
                vboxUnsigned.getChildren().add(labelUnsigned);

                String[][] result = sqlsearcher.getInformation("class", "����183");
                Label[] labelSignedex = new Label[4 * result.length];
                Label[] labelUnsignedex = new Label[2 * result.length];
                HBox[] hbrowsets = new HBox[result.length];
                for(int i = 0; i < result.length; i++) {
                    if(result[i][2].equals("1")){
                        hbrowsets[i] = new HBox();
                        hbrowsets[i].setSpacing(2);
                        hbrowsets[i].setAlignment(Pos.CENTER_LEFT);

                        String[] roominfo = sqlsearcher.getRoomNumber(result[i][0]);

                        labelSignedex[i * 4] = new Label(result[i][0]);
                        labelSignedex[i * 4].setTextFill(Color.valueOf("#62a8ea"));
                        labelSignedex[i * 4].setStyle("-fx-font-weight: bold;");
                        labelSignedex[i * 4].setFont(new Font(20));
                        labelSignedex[i * 4 + 1] = new Label(result[i][1]);


                        labelSignedex[i * 4 + 1].setTextFill(Color.valueOf("#62a8ea"));
                        labelSignedex[i * 4 + 1].setStyle("-fx-font-weight: bold;");
                        labelSignedex[i * 4 + 1].setFont(new Font(20));
                        labelSignedex[i * 4 + 2] = new Label("����ס" + roominfo[0]);
                        labelSignedex[i * 4 + 2].setTextFill(Color.valueOf("#62a8ea"));
                        labelSignedex[i * 4 + 2].setStyle("-fx-font-weight: bold;");
                        labelSignedex[i * 4 + 2].setFont(new Font(20));
                        labelSignedex[i * 4 + 3] = new Label("��λ" + roominfo[1]);
                        labelSignedex[i * 4 + 3].setTextFill(Color.valueOf("#62a8ea"));
                        labelSignedex[i * 4 + 3].setStyle("-fx-font-weight: bold;");
                        labelSignedex[i * 4 + 3].setFont(new Font(20));
                        hbrowsets[i].getChildren().addAll(labelSignedex[i * 4], labelSignedex[i * 4 + 1], labelSignedex[i * 4 + 2], labelSignedex[i * 4 + 3]);
                        vboxSigned.getChildren().add(hbrowsets[i]);
                    }
                    else{
                        hbrowsets[i] = new HBox();
                        hbrowsets[i].setSpacing(2);
                        hbrowsets[i].setAlignment(Pos.CENTER_LEFT);

                        labelUnsignedex[i * 2] = new Label(result[i][0]);
                        labelUnsignedex[i * 2].setTextFill(Color.valueOf("#62a8ea"));
                        labelUnsignedex[i * 2].setStyle("-fx-font-weight: bold;");
                        labelUnsignedex[i * 2].setFont(new Font(20));
                        labelUnsignedex[i * 2 + 1] = new Label(result[i][1]);
                        labelUnsignedex[i * 2 + 1].setTextFill(Color.valueOf("#62a8ea"));
                        labelUnsignedex[i * 2 + 1].setStyle("-fx-font-weight: bold;");
                        labelUnsignedex[i * 2 + 1].setFont(new Font(20));
                        hbrowsets[i].getChildren().addAll(labelUnsignedex[i * 2], labelUnsignedex[i * 2 + 1]);
                        vboxUnsigned.getChildren().add(hbrowsets[i]);
                    }
                }
                vboxsets.getChildren().addAll(vboxSigned, vboxUnsigned);
                sp.setContent(vboxsets);
                mainPane.setCenter(sp);
            }
        });
        
        MenuItem class4= new MenuItem("��ҽ182");
        class4.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                ScrollPane sp = new ScrollPane();
                sp.setPadding(new Insets(25, 25, 25, 25));

                VBox vboxsets = new VBox();
                vboxsets.setSpacing(10);
                vboxsets.setAlignment(Pos.TOP_LEFT);

                VBox vboxSigned = new VBox();
                vboxSigned.setSpacing(10);
                vboxSigned.setAlignment(Pos.TOP_LEFT);

                VBox vboxUnsigned = new VBox();
                vboxUnsigned.setSpacing(10);
                vboxUnsigned.setAlignment(Pos.TOP_LEFT);

                Label labelTitle = new Label("��ҽ182");
                labelTitle.setTextFill(Color.valueOf("#62a8ea"));
                labelTitle.setStyle("-fx-font-weight: bold;");
                labelTitle.setFont(new Font(20));
                Label labelSigned = new Label("����ס");
                labelSigned.setTextFill(Color.valueOf("#62a8ea"));
                labelSigned.setStyle("-fx-font-weight: bold;");
                labelSigned.setFont(new Font(20));
                Label labelUnsigned = new Label("δ��ס");
                labelUnsigned.setTextFill(Color.valueOf("#62a8ea"));
                labelUnsigned.setStyle("-fx-font-weight: bold;");
                labelUnsigned.setFont(new Font(20));

                vboxsets.getChildren().add(labelTitle);
                vboxSigned.getChildren().add(labelSigned);
                vboxUnsigned.getChildren().add(labelUnsigned);

                String[][] result = sqlsearcher.getInformation("class", "��ҽ182");
                Label[] labelSignedex = new Label[4 * result.length];
                Label[] labelUnsignedex = new Label[2 * result.length];
                HBox[] hbrowsets = new HBox[result.length];
                for(int i = 0; i < result.length; i++) {
                    if(result[i][2].equals("1")){
                        hbrowsets[i] = new HBox();
                        hbrowsets[i].setSpacing(2);
                        hbrowsets[i].setAlignment(Pos.CENTER_LEFT);

                        String[] roominfo = sqlsearcher.getRoomNumber(result[i][0]);

                        labelSignedex[i * 4] = new Label(result[i][0]);
                        labelSignedex[i * 4].setTextFill(Color.valueOf("#62a8ea"));
                        labelSignedex[i * 4].setStyle("-fx-font-weight: bold;");
                        labelSignedex[i * 4].setFont(new Font(20));
                        labelSignedex[i * 4 + 1] = new Label(result[i][1]);
                        labelSignedex[i * 4 + 1].setTextFill(Color.valueOf("#62a8ea"));
                        labelSignedex[i * 4 + 1].setStyle("-fx-font-weight: bold;");
                        labelSignedex[i * 4 + 1].setFont(new Font(20));
                        labelSignedex[i * 4 + 2] = new Label("����ס" + roominfo[0]);
                        labelSignedex[i * 4 + 2].setTextFill(Color.valueOf("#62a8ea"));
                        labelSignedex[i * 4 + 2].setStyle("-fx-font-weight: bold;");
                        labelSignedex[i * 4 + 2].setFont(new Font(20));
                        labelSignedex[i * 4 + 3] = new Label("��λ" + roominfo[1]);
                        labelSignedex[i * 4 + 3].setTextFill(Color.valueOf("#62a8ea"));
                        labelSignedex[i * 4 + 3].setStyle("-fx-font-weight: bold;");
                        labelSignedex[i * 4 + 3].setFont(new Font(20));
                        hbrowsets[i].getChildren().addAll(labelSignedex[i * 4], labelSignedex[i * 4 + 1], labelSignedex[i * 4 + 2], labelSignedex[i * 4 + 3]);
                        vboxSigned.getChildren().add(hbrowsets[i]);
                    }
                    else{
                        hbrowsets[i] = new HBox();
                        hbrowsets[i].setSpacing(2);
                        hbrowsets[i].setAlignment(Pos.CENTER_LEFT);

                        labelUnsignedex[i * 2] = new Label(result[i][0]);
                        labelUnsignedex[i * 2].setTextFill(Color.valueOf("#62a8ea"));
                        labelUnsignedex[i * 2].setStyle("-fx-font-weight: bold;");
                        labelUnsignedex[i * 2].setFont(new Font(20));
                        labelUnsignedex[i * 2 + 1] = new Label(result[i][1]);
                        labelUnsignedex[i * 2 + 1].setTextFill(Color.valueOf("#62a8ea"));
                        labelUnsignedex[i * 2 + 1].setStyle("-fx-font-weight: bold;");
                        labelUnsignedex[i * 2 + 1].setFont(new Font(20));
                        hbrowsets[i].getChildren().addAll(labelUnsignedex[i * 2], labelUnsignedex[i * 2 + 1]);
                        vboxUnsigned.getChildren().add(hbrowsets[i]);
                    }
                }
                vboxsets.getChildren().addAll(vboxSigned, vboxUnsigned);
                sp.setContent(vboxsets);
                mainPane.setCenter(sp);
            }
        });
        
        MenuItem class5= new MenuItem("����181");
        class5.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                ScrollPane sp = new ScrollPane();
                sp.setPadding(new Insets(25, 25, 25, 25));

                VBox vboxsets = new VBox();
                vboxsets.setSpacing(10);
                vboxsets.setAlignment(Pos.TOP_LEFT);

                VBox vboxSigned = new VBox();
                vboxSigned.setSpacing(10);
                vboxSigned.setAlignment(Pos.TOP_LEFT);

                VBox vboxUnsigned = new VBox();
                vboxUnsigned.setSpacing(10);
                vboxUnsigned.setAlignment(Pos.TOP_LEFT);

                Label labelTitle = new Label("����181");
                labelTitle.setTextFill(Color.valueOf("#62a8ea"));
                labelTitle.setStyle("-fx-font-weight: bold;");
                labelTitle.setFont(new Font(20));
                Label labelSigned = new Label("����ס");
                labelSigned.setTextFill(Color.valueOf("#62a8ea"));
                labelSigned.setStyle("-fx-font-weight: bold;");
                labelSigned.setFont(new Font(20));
                Label labelUnsigned = new Label("δ��ס");
                labelUnsigned.setTextFill(Color.valueOf("#62a8ea"));
                labelUnsigned.setStyle("-fx-font-weight: bold;");
                labelUnsigned.setFont(new Font(20));

                vboxsets.getChildren().add(labelTitle);
                vboxSigned.getChildren().add(labelSigned);
                vboxUnsigned.getChildren().add(labelUnsigned);

                String[][] result = sqlsearcher.getInformation("class", "����181");
                Label[] labelSignedex = new Label[4 * result.length];
                Label[] labelUnsignedex = new Label[2 * result.length];
                HBox[] hbrowsets = new HBox[result.length];
                for(int i = 0; i < result.length; i++) {
                    if(result[i][2].equals("1")){
                        hbrowsets[i] = new HBox();
                        hbrowsets[i].setSpacing(2);
                        hbrowsets[i].setAlignment(Pos.CENTER_LEFT);

                        String[] roominfo = sqlsearcher.getRoomNumber(result[i][0]);

                        labelSignedex[i * 4] = new Label(result[i][0]);
                        labelSignedex[i * 4].setTextFill(Color.valueOf("#62a8ea"));
                        labelSignedex[i * 4].setStyle("-fx-font-weight: bold;");
                        labelSignedex[i * 4].setFont(new Font(20));
                        labelSignedex[i * 4 + 1] = new Label(result[i][1]);
                        labelSignedex[i * 4 + 1].setTextFill(Color.valueOf("#62a8ea"));
                        labelSignedex[i * 4 + 1].setStyle("-fx-font-weight: bold;");
                        labelSignedex[i * 4 + 1].setFont(new Font(20));
                        labelSignedex[i * 4 + 2] = new Label("����ס" + roominfo[0]);
                        labelSignedex[i * 4 + 2].setTextFill(Color.valueOf("#62a8ea"));
                        labelSignedex[i * 4 + 2].setStyle("-fx-font-weight: bold;");
                        labelSignedex[i * 4 + 2].setFont(new Font(20));
                        labelSignedex[i * 4 + 3] = new Label("��λ" + roominfo[1]);
                        labelSignedex[i * 4 + 3].setTextFill(Color.valueOf("#62a8ea"));
                        labelSignedex[i * 4 + 3].setStyle("-fx-font-weight: bold;");
                        labelSignedex[i * 4 + 3].setFont(new Font(20));
                        hbrowsets[i].getChildren().addAll(labelSignedex[i * 4], labelSignedex[i * 4 + 1], labelSignedex[i * 4 + 2], labelSignedex[i * 4 + 3]);
                        vboxSigned.getChildren().add(hbrowsets[i]);
                    }
                    else{
                        hbrowsets[i] = new HBox();
                        hbrowsets[i].setSpacing(2);
                        hbrowsets[i].setAlignment(Pos.CENTER_LEFT);

                        labelUnsignedex[i * 2] = new Label(result[i][0]);
                        labelUnsignedex[i * 2].setTextFill(Color.valueOf("#62a8ea"));
                        labelUnsignedex[i * 2].setStyle("-fx-font-weight: bold;");
                        labelUnsignedex[i * 2].setFont(new Font(20));
                        labelUnsignedex[i * 2 + 1] = new Label(result[i][1]);
                        labelUnsignedex[i * 2 + 1].setTextFill(Color.valueOf("#62a8ea"));
                        labelUnsignedex[i * 2 + 1].setStyle("-fx-font-weight: bold;");
                        labelUnsignedex[i * 2 + 1].setFont(new Font(20));
                        hbrowsets[i].getChildren().addAll(labelUnsignedex[i * 2], labelUnsignedex[i * 2 + 1]);
                        vboxUnsigned.getChildren().add(hbrowsets[i]);
                    }
                }
                vboxsets.getChildren().addAll(vboxSigned, vboxUnsigned);
                sp.setContent(vboxsets);
                mainPane.setCenter(sp);
            }
        });
        
        menuclass.getItems().addAll(class1,class2,class3,class4,class5);
        
        Menu dormitory1 = new Menu("1¥");
        
        Menu dormitory2 = new Menu("2¥");
        
        Menu dormitory3 = new Menu("3¥");
        
        menudormitory.getItems().addAll(dormitory1,dormitory2,dormitory3);

        RadioMenuItem[] dor = new RadioMenuItem[30];
        for(int i = 0; i < 30; i++){
                if(i % 10 == 9){
                        dor[i] = new RadioMenuItem((i / 10 + 1) + "10");
                }
                else {
                        dor[i] = new RadioMenuItem("" + (i / 10 + 1) + "0" + (i % 10 + 1));
                }
                if(i / 10 == 0){
                        dormitory1.getItems().add(dor[i]);
                }
                else if(i /10 == 1){
                        dormitory2.getItems().add(dor[i]);
                }
                else{
                        dormitory3.getItems().add(dor[i]);
                }
                final int fi = i;
                dor[i].setOnAction(new EventHandler<ActionEvent>() {
                        @Override
                        public void handle(ActionEvent event) {
                                ScrollPane sp = new ScrollPane();
                                sp.setPadding(new Insets(25, 25, 25, 25));
                                SQLdormitory sqLdormitory = new SQLdormitory();
                                String[][] info = null;
                                if(fi % 10 == 9){
                                    info = sqLdormitory.getInformation("roomId", (fi / 10 + 1) + "10");
                                }
                                else{
                                    info = sqLdormitory.getInformation("roomId", (fi / 10 + 1) + "0" + (fi % 10 + 1));
                                }
                                VBox vboxsets = new VBox();
                                vboxsets.setAlignment(Pos.TOP_LEFT);
                                vboxsets.setSpacing(5);

                                HBox[] hBoxes = new HBox[5];
                                for(int i = 0; i < 5; i++){
                                    if(i == 0){
                                        Label labelTitle = null;
                                        if(fi % 10 == 9){
                                            labelTitle = new Label("����" + (fi / 10 + 1) + "10");
                                            labelTitle.setTextFill(Color.valueOf("#62a8ea"));
                                            labelTitle.setStyle("-fx-font-weight: bold;");
                                            labelTitle.setFont(new Font(20));
                                        }
                                        else {
                                            labelTitle = new Label("����" + (fi / 10 + 1) + "0" + (fi % 10 + 1));
                                            labelTitle.setTextFill(Color.valueOf("#62a8ea"));
                                            labelTitle.setStyle("-fx-font-weight: bold;");
                                            labelTitle.setFont(new Font(20));
                                        }
                                        hBoxes[i] = new HBox();
                                        hBoxes[i].setAlignment(Pos.CENTER_LEFT);
                                        hBoxes[i].getChildren().add(labelTitle);
                                        vboxsets.getChildren().add(hBoxes[i]);
                                    }
                                    else {
                                        Label labelBedTitle = new Label("��λ" + i + ":");
                                        labelBedTitle.setTextFill(Color.valueOf("#62a8ea"));
                                        labelBedTitle.setStyle("-fx-font-weight: bold;");
                                        labelBedTitle.setFont(new Font(20));
                                        hBoxes[i] = new HBox();
                                        hBoxes[i].setAlignment(Pos.CENTER_LEFT);
                                        hBoxes[i].setSpacing(3);
                                        if(info[0][i].equals("��")){
                                            Label labelnun = new Label("��");
                                            hBoxes[i].getChildren().add(labelnun);
                                        }
                                        else{
                                            String[][] infoName = sqLdormitory.getInformation("stuName", info[0][i]);
                                            Label labelname = new Label(infoName[0][0]);
                                            labelname.setTextFill(Color.valueOf("#62a8ea"));
                                            labelname.setStyle("-fx-font-weight: bold;");
                                            labelname.setFont(new Font(20));
                                            Label labelnum = new Label(infoName[0][1]);
                                            labelnum.setTextFill(Color.valueOf("#62a8ea"));
                                            labelnum.setStyle("-fx-font-weight: bold;");
                                            labelnum.setFont(new Font(20));
                                            hBoxes[i].getChildren().addAll(labelname, labelnum);
                                        }
                                        vboxsets.getChildren().add(hBoxes[i]);
                                    }
                                }
                                sp.setContent(vboxsets);
                                mainPane.setCenter(sp);
                        }
                });
        }
        Button backToSign = new Button("���صǼ�ҳ");
        backToSign.setStyle("{-fx-font-size:20;  -fx-background-color:#62a8ea; -fx-text-fill:white; -fx-font-size:15;}");
        backToSign.setPrefWidth(245.0);
        backToSign.setPrefHeight(10.0);
        backToSign.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                try{
                    examine e = new examine();
                    e.setSQLpassword(SQLpassword);
                    e.setSQLaccess(SQLaccess);
                    Stage stage = new Stage();
                    e.start(stage);
                    primaryStage.close();
                }
                catch (Exception e){
                    showMessage("���ִ���");
                }

            }
        });
        
        mainPane.setTop(vbox);
        mainPane.setBottom(backToSign);
     
        primaryStage.setTitle("���ҹ���ϵͳ");
        primaryStage.setScene(sceneMain);
        primaryStage.show();

	}
    public static void showMessage(String MessageText){
        Alert information = new Alert(Alert.AlertType.INFORMATION,MessageText);
        information.setTitle("����");         //���ñ���
        information.showAndWait();   //��ʾ������ͬʱ��������ȹ���
    }
}
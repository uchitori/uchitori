

import java.sql.*;
import java.util.ArrayList;
import java.util.Scanner;

public interface SQLinterface {
    public static void main(String[] args) throws Exception{
        try {
            SQLdormitory sqLdormitory = new SQLdormitory();
            String[][] s = sqLdormitory.getInformation("roomId", "101");
            String[] s2 = sqLdormitory.getRoomNumber("��è");
            System.out.print(s[0][0] + " ");
            System.out.print(s[0][1] + " ");
            System.out.println(s[0][2] + " ");
            System.out.print(s2[0] + " ");
            System.out.println(s2[1] + " ");
        }
        /*catch(SQLException se){
            // ���� JDBC ����
            se.printStackTrace();
        }*/catch(Exception e){
            // ���� Class.forName ����
            e.printStackTrace();
        }

    }

    public String getAccess() throws Exception;
    /*������£�
    1.����Ա�˺�������ȷ�򷵻� admin authenation succeed
    2.����Ա�˺Ŵ��󷵻� adminAccessIncorrect
    3.����Ա������󷵻� adminPasswordIncorrect
    4.ѧ���˺�������ȷ�򷵻� student authencation succeed
    5.ѧ����������򷵻� studentPasswordIncorrect
    6.ѧ���˺Ŵ����򷵻� studentAccessNOTFOUND
    7.�����bug�����ܷ��� unknownERROR
     */

    public String setPassword(String newPassword) throws Exception;
    /*
    1.������������п��ܸ���sql���ݿ�ķǷ����ţ��򷵻� ����������Ƿ��ַ�
    2.û��������������� �����޸ĳɹ�
    3.ԭ��������򷵻� ԭ�������
    4.��bugʱ��Ҳ���ܷ��� ԭ�������
    */

    public String Signin(String roomNum, int bedNum, String inStuId);

    public String Signout(String roomNum, int bedNum);

    public void setIsAdmin(boolean inIsAdmin);

    public void setAuthencation(boolean inAuthencation);

    public void setSQLPassword(String inSQLPassword);

    public void setSQLAccess(String inSQLAccess);

    public boolean testConnection();

    public String getSQLAccess();

    public String getSQLPassword();

    public String[][] getInformation(String method, String keyword);

    public String[] getRoomNumber(String name);

    public boolean studentIdentifier(String inStuNum, String inStuName, String inStuColleget, String inStuDepart, String inStuClass);

}
//������ʱ��ʹ��SQLdormitory
//public SQLdormitory(String inAccess, String inPassword, boolean inIsAdmin);

class SQLdormitory implements SQLinterface{
    private String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    private String DB_URL = "jdbc:mysql://localhost:3306/dormitory";

    private String USER = "root";           //mysql�˻�
    private String PASS = "7M14ebr5Po";     //mysql�˻�����

    private boolean initialization = false;

    private String Access = "";
    private String Password = "";
    private boolean isAdmin = false;
    private boolean authencation = false;

    public SQLdormitory(String inAccess, String inPassword, boolean inIsAdmin){
        this.Access = inAccess.replaceAll(".*([';]+|(--)+).*", " ");
        this.Password = inPassword.replaceAll(".*([';]+|(--)+).*", " ");
        this.isAdmin = inIsAdmin;
    }

    public SQLdormitory(){
        this.Access = "";
        this.Password = "";
        this.isAdmin = false;
    }

    public void setIsAdmin(boolean inIsAdmin){
        this.isAdmin = inIsAdmin;
    }

    public void setAuthencation(boolean inAuthencation){
        this.authencation = inAuthencation;
    }

    public void setSQLPassword(String inSQLPassword){
        this.PASS = inSQLPassword;
    }

    public void setSQLAccess(String inSQLAccess){
        this.USER = inSQLAccess;
    }

    public String getSQLAccess(){
        return this.USER;
    }

    public String getSQLPassword(){
        return this.PASS;
    }

    public String[] getRoomNumber(String name){
        Connection conn = null;
        Statement stmt = null;
        try{
            // ע�� JDBC ����
            Class.forName("com.mysql.jdbc.Driver");

            // ������
            conn = DriverManager.getConnection(DB_URL,USER,PASS);

            // ִ�в�ѯ
            stmt = conn.createStatement();
            String sql = "SELECT roomId FROM roominfo WHERE (bed1 <=> \"" + name + "\") " +
                    "OR (bed2 <=> \"" + name + "\") " +
                    "OR (bed3 <=> \"" + name + "\") " +
                    "OR (bed4 <=> \"" + name + "\")";
            ResultSet rs = stmt.executeQuery(sql);

            String[] outRoomNum = new String[2];
            while(rs.next()) {
                outRoomNum[0] = rs.getString("roomId");
            }
            sql = "SELECT IF(" +
                    "bed4 <=> \"" + name + "\", 4, IF(" +
                    "bed3 <=> \"" + name + "\", 3, IF(" +
                    "bed2 <=> \"" + name + "\", 2, 1)" +
                    ")" +
                    ")" +
                    "bednum FROM roominfo WHERE roomId <=> \"" + outRoomNum[0] + "\"";
            rs = stmt.executeQuery(sql);
            while(rs.next()){
                outRoomNum[1] = rs.getString("bednum");
            }
            // ��ɺ�ر�
            rs.close();
            stmt.close();
            conn.close();
            return outRoomNum;
        }catch(SQLException se){
            // ���� JDBC ����
            se.printStackTrace();
        }catch(Exception e){
            // ���� Class.forName ����
            e.printStackTrace();
        }finally{
            // �ر���Դ
            try{
                if(stmt!=null) stmt.close();
            }catch(SQLException se2){
            }// ʲô������
            try{
                if(conn!=null) conn.close();
            }catch(SQLException se){
                se.printStackTrace();
            }
        }
        return null;
    }


    public boolean testConnection(){
        Connection conn = null;
        Statement stmt = null;
        try{
            // ע�� JDBC ����
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection(DB_URL,USER,PASS);


            stmt = conn.createStatement();
            String sql;
            if(isAdmin) {
                sql = "SELECT name, password FROM admininfo";
            }
            else{
                sql = "SELECT stuId, password FROM studentinfo";
            }

            // ��ɺ�ر�
            stmt.close();
            conn.close();

        }catch(SQLException se){
            // ���� JDBC ����
            se.printStackTrace();
            return false;
        }catch(Exception e){
            // ���� Class.forName ����
            e.printStackTrace();
            return false;
        }finally{
            // �ر���Դ
            try{
                if(stmt!=null) stmt.close();
            }
            catch(SQLException se2){
                return false;
            }// ʲô������
            try{
                if(conn!=null) conn.close();
            }catch(SQLException se){
                se.printStackTrace();
                return false;
            }
        }
        return true;
    }

    public String getAccess() throws Exception{
        Connection conn = null;
        Statement stmt = null;
        try{
            // ע�� JDBC ����
            Class.forName("com.mysql.jdbc.Driver");

            // ������
            System.out.println("�������ݿ�...");
            conn = DriverManager.getConnection(DB_URL,USER,PASS);

            // ִ�в�ѯ
            System.out.println(" ʵ����Statement����...");
            stmt = conn.createStatement();
            String sql;
            if(isAdmin) {
                sql = "SELECT name, password FROM admininfo";
            }
            else{
                sql = "SELECT stuId, password FROM studentinfo";
            }
            ResultSet rs = stmt.executeQuery(sql);

            while(rs.next()){
                if(isAdmin) {
                    String rsAccess = rs.getString("name");
                    String rsPassword = rs.getString("password");
                    if(Access.equals(rsAccess)){
                        if(Password.equals(rsPassword)){
                            authencation = true;
                            rs.close();
                            stmt.close();
                            conn.close();
                            return "admin authencation succeed";
                        }
                        else if(!rs.next()){
                            rs.close();
                            stmt.close();
                            conn.close();
                            return "adminPasswordIncorrect";
                        }
                    }
                    else if(!rs.next()){
                        rs.close();
                        stmt.close();
                        conn.close();
                        return "adminAccessIncorrect";
                    }
                }
                else {
                    String rsAccess = rs.getString("stuId");
                    String rsPassword = rs.getString("password");
                    if(Access.equals(rsAccess)){
                        if(rsPassword == null){
                            String iniPassword = rsAccess.substring(2);
                            sql = "UPDATE studentinfo SET password = \'" + iniPassword + "\' WHERE stuId <=> \'" + rsAccess + "\'";
                            stmt.execute(sql);
                            sql = "UPDATE studentinfo SET isPrimaryLogin = 0 WHERE stuId <=> \"" + rsAccess + "\"";
                            Password = iniPassword;
                        }
                        if(Password.equals(rsPassword)){
                            authencation = true;
                            rs.close();
                            stmt.close();
                            conn.close();
                            return "student authencation succeed";
                        }
                        else {
                            rs.close();
                            stmt.close();
                            conn.close();
                            return "studentPasswordIncorrect";
                        }

                    }
                }
            }

            // ��ɺ�ر�
            rs.close();
            stmt.close();
            conn.close();


        }catch(SQLException se){
            // ���� JDBC ����
            se.printStackTrace();
        }catch(Exception e){
            // ���� Class.forName ����
            e.printStackTrace();
        }finally{
            // �ر���Դ
            try{
                if(stmt!=null) stmt.close();
            }
            catch(SQLException se2){

            }// ʲô������
            try{
                if(conn!=null) conn.close();
            }catch(SQLException se){
                se.printStackTrace();
            }
        }
        if(!isAdmin) {
            return "studentAccessNOTFOUND";
        }
        else{
            return "unknownERROR";
        }
    }

    public String setPassword(String newPassword) throws Exception{
        Connection conn = null;
        Statement stmt = null;
        try{
            // ע�� JDBC ����
            Class.forName("com.mysql.jdbc.Driver");

            // ������
            System.out.println("�������ݿ�...");
            conn = DriverManager.getConnection(DB_URL,USER,PASS);

            // ִ�в�ѯ
            System.out.println(" ʵ����Statement����...");
            stmt = conn.createStatement();
            String sql;
            ResultSet rs = null;
            sql = "SELECT isPrimaryLogin FROM studentinfo WHERE stuId <=> \"" + Access + "\"";
            rs = stmt.executeQuery(sql);
            boolean isPrimaryLogin = true;
            while (rs.next()){
                if(rs.getInt("isPrimaryLogin") == 1){
                    isPrimaryLogin = false;
                }
            }
            if(Access.equals("")){
                return "�˺�Ϊ��!";
            }
            if(authencation && isPrimaryLogin) {
                if(newPassword.replaceAll(".*([';]+|(--)+).*", " ").length() != newPassword.replaceAll(".*([';]+|(--)+).*", " ").length()){
                    return "����������Ƿ��ַ���";
                }
                if (isAdmin) {
                    sql = "UPDATE admininfo SET password = /'" + newPassword + "/'";
                    stmt.execute(sql);
                } else {
                    sql = "UPDATE studentinfo SET password = /'" + newPassword + "/'WHERE stuId <=> /'" + Access + "/'";
                }
                return "�����޸ĳɹ���";
            }

            // ��ɺ�ر�
            rs.close();
            stmt.close();
            conn.close();

        }catch(SQLException se){
            // ���� JDBC ����
            se.printStackTrace();
        }catch(Exception e){
            // ���� Class.forName ����
            e.printStackTrace();
        }finally{
            // �ر���Դ
            try{
                if(stmt!=null) stmt.close();
            }catch(SQLException se2){
            }// ʲô������
            try{
                if(conn!=null) conn.close();
            }catch(SQLException se){
                se.printStackTrace();
            }
        }
        if(!authencation) {
            return "ԭ�������";
        }
        else{
            return "���ε�½��ʹ�ó�ʼ�����½ȷ�Ϻ��ٸ������룡(��ʼ����Ϊѧ�ź���λ)";
        }
    }

    public String Signin(String roomNum, int bedNum, String inStuId){
        Connection conn = null;
        Statement stmt = null;
        try{
            if(bedNum < 0 || bedNum > 5){
                return "��λ���Ϸ���";
            }
            // ע�� JDBC ����
            Class.forName("com.mysql.jdbc.Driver");

            // ������
            conn = DriverManager.getConnection(DB_URL,USER,PASS);

            // ִ�в�ѯ
            stmt = conn.createStatement();
            String sql = "SELECT stuName, isCheckIn FROM studentinfo WHERE stuId <=>\"" + inStuId + "\"";

            ResultSet rs = stmt.executeQuery(sql);
            String ischeck = null;
            String stuName = null;
            while (rs.next()){
                stuName = rs.getString("stuName");
                ischeck = rs.getString("isCheckIn");
            }
            if(ischeck == "1"){
                rs.close();
                stmt.close();
                conn.close();
                return "��ѧ������ס��";
            }

            sql = "UPDATE roominfo SET bed" + bedNum + " = \"" + stuName + "\" WHERE roomId <=> \"" + roomNum + "\"";
            stmt.execute(sql);
            sql = "UPDATE studentinfo SET isCheckIn = 1 WHERE stuName <=> \"" + stuName + "\"";
            stmt.execute(sql);
            // ��ɺ�ر�
            rs.close();
            stmt.close();
            conn.close();
        }catch(SQLException se){
            // ���� JDBC ����
            se.printStackTrace();
        }catch(Exception e){
            // ���� Class.forName ����
            e.printStackTrace();
        }finally{
            // �ر���Դ
            try{
                if(stmt!=null) stmt.close();
            }catch(SQLException se2){
            }// ʲô������
            try{
                if(conn!=null) conn.close();
            }catch(SQLException se){
                se.printStackTrace();
            }
        }
        return "��λ�޸ĳɹ���";
    }

    public String Signout(String roomNum, int bedNum){
        Connection conn = null;
        Statement stmt = null;
        try{
            // ע�� JDBC ����
            Class.forName("com.mysql.jdbc.Driver");

            // ������
            conn = DriverManager.getConnection(DB_URL,USER,PASS);

            // ִ�в�ѯ
            stmt = conn.createStatement();
            String sql;
            sql = "SELECT bed" + bedNum + " FROM roominfo WHERE roomId <=> \"" + roomNum + "\"";
            ResultSet rs = stmt.executeQuery(sql);
            String stuName = null;
            String stuNum = null;
            while (rs.next()){
                stuName = rs.getString("bed" + bedNum);
            }
            sql = "SELECT stuId FROM studentinfo WHERE (stuName <=> \"" + stuName + "\") AND (isCheckIn <=> 1)";
            rs = stmt.executeQuery(sql);
            while (rs.next()){
                stuNum = rs.getString("stuId");
            }
            sql = "UPDATE roominfo SET bed" + bedNum + " = \"��\" WHERE roomId <=> \"" + roomNum + "\"";
            stmt.execute(sql);
            sql = "UPDATE studentinfo SET isCheckIn = 0 WHERE stuId <=> \"" + stuNum + "\"";
            stmt.execute(sql);
            stmt.close();
            conn.close();
        }catch(SQLException se){
            // ���� JDBC ����
            se.printStackTrace();
        }catch(Exception e){
            // ���� Class.forName ����
            e.printStackTrace();
        }finally{
            // �ر���Դ
            try{
                if(stmt!=null) stmt.close();
            }catch(SQLException se2){
            }// ʲô������
            try{
                if(conn!=null) conn.close();
            }catch(SQLException se){
                se.printStackTrace();
            }
        }
        return "�˷��ɹ���";
    }

    public String[][] getInformation(String method, String keyword){
        Connection conn = null;
        Statement stmt = null;
        try{
            // ע�� JDBC ����
            Class.forName("com.mysql.jdbc.Driver");

            // ������
            conn = DriverManager.getConnection(DB_URL,USER,PASS);

            // ִ�в�ѯ
            stmt = conn.createStatement();
            String sql = null;
            if(method.equals("roomId")){
                sql = "SELECT bed1, bed2, bed3, bed4 FROM roominfo WHERE roomId <=> \"" + keyword + "\"";
            }
            else {
                sql = "SELECT stuName, stuId, isCheckIn FROM studentinfo WHERE " + method + " <=> \"" + keyword + "\"";
            }
            ResultSet rs = stmt.executeQuery(sql);
            rs.last();
            int count = rs.getRow();
            rs.beforeFirst();

            String[][] InformationSet = new String[count][3];
            String[][] singleInformationLine = new String[1][5];
            int t = 0;
            // չ����������ݿ�
            while(rs.next()){
                // ͨ���ֶμ���
                if(!method.equals("roomId")) {
                    InformationSet[t][0] = rs.getString("stuName");
                    InformationSet[t][1] = rs.getString("stuId");
                    InformationSet[t][2] = String.valueOf(rs.getInt("isCheckIn"));
                    t++;
                }
                else{
                    singleInformationLine[0][0] = keyword;
                    singleInformationLine[0][1] = rs.getString("bed1");
                    singleInformationLine[0][2] = rs.getString("bed2");
                    singleInformationLine[0][3] = rs.getString("bed3");
                    singleInformationLine[0][4] = rs.getString("bed4");
                }

            }
            // ��ɺ�ر�
            rs.close();
            stmt.close();
            conn.close();
            if(method.equals("roomId")){
                return singleInformationLine;
            }
            else{
                return InformationSet;
            }
        }catch(SQLException se){
            // ���� JDBC ����
            se.printStackTrace();
        }catch(Exception e){
            // ���� Class.forName ����
            e.printStackTrace();
        }finally{
            // �ر���Դ
            try{
                if(stmt!=null) stmt.close();
            }catch(SQLException se2){
            }// ʲô������
            try{
                if(conn!=null) conn.close();
            }catch(SQLException se){
                se.printStackTrace();
            }
        }
        return null;
    }

    public boolean studentIdentifier(String inStuNum, String inStuName, String inStuColleget, String inStuDepart, String inStuClass){
        Connection conn = null;
        Statement stmt = null;
        try{
            // ע�� JDBC ����
            Class.forName("com.mysql.jdbc.Driver");

            // ������
            conn = DriverManager.getConnection(DB_URL,USER,PASS);

            // ִ�в�ѯ
            stmt = conn.createStatement();
            String sql;
            sql = "SELECT stuId, stuName, colleget, department, class FROM studentinfo WHERE stuId <=> \"" + inStuNum + "\"";
            ResultSet rs = stmt.executeQuery(sql);
            String[] inputset = new String[4];
            // չ����������ݿ�
            while(rs.next()){
                // ͨ���ֶμ���
                inputset[0] = rs.getString("stuName");
                inputset[1] = rs.getString("colleget");
                inputset[2] = rs.getString("department");
                inputset[3] = rs.getString("class");
            }
            // ��ɺ�ر�
            rs.close();
            stmt.close();
            conn.close();
            if(inputset[0].equals(inStuName) && inputset[1].equals(inStuColleget) && inputset[2].equals(inStuDepart) && inputset[3].equals(inStuClass)){
                return true;
            }
        }catch(SQLException se){
            // ���� JDBC ����
            se.printStackTrace();
        }catch(Exception e){
            // ���� Class.forName ����
            e.printStackTrace();
        }finally{
            // �ر���Դ
            try{
                if(stmt!=null) stmt.close();
            }catch(SQLException se2){
            }// ʲô������
            try{
                if(conn!=null) conn.close();
            }catch(SQLException se){
                se.printStackTrace();
            }
        }
        return false;
    }
}



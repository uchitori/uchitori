import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.control.Label;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.shape.*;
import javafx.stage.Stage;

public class examine extends Application{
    private String SQLaccess = "root";
    private String SQLpassword = "7M14ebr5Po";
    public void setSQLpassword(String string){this.SQLpassword = string;}
    public void setSQLaccess(String string){this.SQLaccess = string;}
    public static void main(String[] args){
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        SQLdormitory sqLdormitory = new SQLdormitory();
        boolean[] roomstat = new boolean[30];
        for(int i = 0; i < 30; i++){
            String input = "";
            if(i % 10 == 9){
                input = (i / 10 + 1) + "10";
            }
            else{
                input = (i / 10 + 1) + "0" + (i % 10 + 1);
            }
            String[][] info = sqLdormitory.getInformation("roomId", input);
            if(!info[0][1].equals("��") && !info[0][2].equals("��") && !info[0][3].equals("��") && !info[0][4].equals("��")){
                roomstat[i] = true;
            }
            else {
                roomstat[i] = false;
            }
        }

        BorderPane mainPane = new BorderPane();
        mainPane.setPadding(new Insets(25, 25, 25, 25));

        BorderPane insertionBP = new BorderPane();
        mainPane.setPadding(new Insets(25, 25, 25,25));

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(25, 25, 25,25 ));
        grid.setVgap(5);
        grid.setHgap(5);
        grid.setAlignment(Pos.CENTER);

        Scene sceneMain = new Scene(mainPane,900, 400);

        /*Scene sceneManager = new Scene();*/

        Label labelDomitList = new Label("�� �� �� ��");
        labelDomitList.setAlignment(Pos.CENTER);
        labelDomitList.setTextFill(Color.valueOf("#62a8ea"));
        labelDomitList.setStyle("-fx-font-weight: bold");
        labelDomitList.setFont(new Font(30));
	    
        HBox Domitlb = new HBox();
        Domitlb.setPadding(new Insets(25, 25, 25, 25));
        Domitlb.setAlignment(Pos.CENTER);
        Domitlb.getChildren().addAll(labelDomitList);

        TextField textChooseDom = new TextField();
        textChooseDom.setPrefWidth(50);
        textChooseDom.setPrefHeight(20);
        textChooseDom.textProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                if(!oldValue.equals("") && newValue.length() != 3){
                    showMessage("��ѡ��ť��ȷ����Ҫ��ס�����ң�");
                    textChooseDom.setText("");
                }
            }
        });

        Button[] btnroom = new Button[30];
        for(int i = 0; i < 30; i++){
            btnroom[i] = new Button();
            if(!roomstat[i]) {
                btnroom[i].setStyle("-fx-background-color: yellow; -fx-font-size:20;-fx-text-fill:white; -fx-font-size:15;");
                btnroom[i].setPrefWidth(245.0);
                btnroom[i].setPrefHeight(10.0);
            }
            else {
                  btnroom[i].setStyle("{-fx-font-size:20;  -fx-background-color:red; -fx-text-fill:white; -fx-font-size:15;}");
                  btnroom[i].setPrefWidth(245.0);
                  btnroom[i].setPrefHeight(10.0);
            }
            if(i % 10 == 9){
                btnroom[i].setText(((i / 10) + 1) + "10");
            }
            else {
                btnroom[i].setText(((i / 10) + 1) + "0" + (i % 10 + 1));
            }
            final int finedI = i;
            btnroom[i].setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    if(roomstat[finedI]){
                        showMessage("����������");
                    }
                    else {
                        if (finedI % 10 == 9) {
                            textChooseDom.setText(((finedI / 10) + 1) + "10");
                        } else {
                            textChooseDom.setText(((finedI / 10) + 1) + "0" + (finedI % 10 + 1));
                        }
                    }
                }
            });
             grid.add(btnroom[i], i % 10, i / 10);
         }

        Rectangle recRed = new Rectangle(50, 35, Color.RED);
        Rectangle recYellow = new Rectangle(50, 35, Color.YELLOW);
        Label labelFull = new Label("����");
        Label labelEmpty = new Label("δ��");
        HBox fullAndEmpty = new HBox();
        fullAndEmpty.setPadding(new Insets(0, 25, 0, 25));
        fullAndEmpty.setSpacing(8);
        fullAndEmpty.getChildren().addAll(recRed, labelFull, recYellow, labelEmpty);
        fullAndEmpty.setAlignment(Pos.CENTER);

        Label labelChooseDom = new Label("��ѡ���������");
        labelChooseDom.setTextFill(Color.valueOf("#62a8ea"));
        labelChooseDom.setStyle("-fx-font-weight: bold;");
        labelChooseDom.setFont(new Font(20));

        Button btnEnterChoosePage = new Button();
        btnEnterChoosePage.setText("������ס");
        btnEnterChoosePage.setStyle("{-fx-font-size:20;  -fx-background-color:#62a8ea; -fx-text-fill:white; -fx-font-size:15;}");
        btnEnterChoosePage.setPrefWidth(150.0);
        btnEnterChoosePage.setPrefHeight(10.0);
        btnEnterChoosePage.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                try {
                    if(textChooseDom.getText().equals("")){
                        showMessage("����δѡ�����ң�");
                    }
                    else {
                        inregister Inregister = new inregister();
                        Inregister.setRoomNum(textChooseDom.getText());
                        Stage secondStage = new Stage();
                        Inregister.start(secondStage);
                        primaryStage.close();
                    }
                }
                catch (Exception e){
                    showMessage("�����쳣��");
                }
            }
        });
        Button btnEnterCheckoutPage = new Button();
        btnEnterCheckoutPage.setText("�����˷�");
        btnEnterCheckoutPage.setStyle("{-fx-font-size:20;  -fx-background-color:#62a8ea; -fx-text-fill:white; -fx-font-size:15;}");
        btnEnterCheckoutPage.setPrefWidth(150.0);
        btnEnterCheckoutPage.setPrefHeight(10.0);
        btnEnterCheckoutPage.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                try {
                    if(textChooseDom.getText().equals("")){
                        showMessage("����δѡ�����ң�");
                    }
                    else {
                        checkout out = new checkout();
                        out.setRoomNum(textChooseDom.getText());
                        out.setSQLaccess(SQLaccess);
                        out.setSQLpassword(SQLpassword);
                        Stage secondStage = new Stage();
                        out.start(secondStage);
                        primaryStage.close();
                    }
                } catch (Exception e){
                    showMessage("�����쳣!");
                }
            }
        });

        Button btnGotoSearch = new Button("ǰ������ҳ");
        btnGotoSearch.setStyle("{-fx-font-size:20;  -fx-background-color:#62a8ea; -fx-text-fill:white; -fx-font-size:15;}");
        btnGotoSearch.setPrefWidth(150.0);
        btnGotoSearch.setPrefHeight(10.0);
        btnGotoSearch.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                try {
                    search s = new search();
                    s.setSQLaccess(SQLaccess);
                    s.setSQLpassword(SQLpassword);
                    Stage stage = new Stage();
                    s.start(stage);
                    primaryStage.close();
                }
                catch (Exception e){
                    showMessage("�����쳣!");
                }
            }
        });
        HBox DomitChooseSets = new HBox();
        DomitChooseSets.setPadding(new Insets(25, 25, 25, 25));
        DomitChooseSets.setSpacing(10);
        DomitChooseSets.getChildren().addAll(labelChooseDom, textChooseDom, btnEnterChoosePage, btnEnterCheckoutPage, btnGotoSearch);
        DomitChooseSets.setAlignment(Pos.CENTER);

        insertionBP.setCenter(grid);
        insertionBP.setBottom(fullAndEmpty);

        mainPane.setCenter(insertionBP);
        mainPane.setTop(Domitlb);
        mainPane.setBottom(DomitChooseSets);

        primaryStage.setTitle("���ҹ���ϵͳ");
        primaryStage.setScene(sceneMain);
        primaryStage.show();
    }
    public static void showMessage(String MessageText){
        Alert information = new Alert(Alert.AlertType.INFORMATION,MessageText);
        information.setTitle("����");         //���ñ���
        information.showAndWait();   //��ʾ������ͬʱ��������ȹ���
    }
}


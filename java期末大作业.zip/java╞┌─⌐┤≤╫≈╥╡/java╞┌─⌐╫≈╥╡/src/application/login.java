



import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.sql.SQLException;

public class login extends Application{
    private String SQLaccess = "root";
    private String SQLpassword = "7M14ebr5Po";
    public void setSQLpassword(String string){this.SQLpassword = string;}
    public void setSQLaccess(String string){this.SQLaccess = string;}
    public static void main(String[] args) {
        // TODO Auto-generated method stub
        launch(args);
    }



    @Override
    public void start(Stage primaryStage) {
        // TODO Auto-generated method stub
        Stage secondStage = new Stage();
        Stage thirdStage = new Stage();

        BorderPane mainPane = new BorderPane();
        mainPane.setPadding(new Insets(10, 25, 25, 25));


        GridPane grid = new GridPane();
        grid.setPadding(new Insets(0, 25, 25,25 ));
        grid.setVgap(10);
        grid.setHgap(5);
        grid.setAlignment(Pos.CENTER);

        Scene sceneMain = new Scene(mainPane,520,300);


        Label labeltitle = new Label("�� �� Ա �� ½");
        labeltitle.setAlignment(Pos.CENTER);
        labeltitle.setTextFill(Color.valueOf("#62a8ea"));
        labeltitle.setStyle("-fx-font-weight: bold");
        labeltitle.setFont(new Font(30));
        
        HBox hbox = new HBox();
        hbox.setPadding(new Insets(25, 25, 25, 25));
        hbox.setAlignment(Pos.CENTER);
        hbox.getChildren().addAll(labeltitle);

        TextField textaccount = new TextField();
        textaccount.setStyle("{-fx-text-fill:#cccccc;-fx-font-size:20;}");
        textaccount.setText("�������˺�");
        textaccount.setOpacity(0.5);
        textaccount.setPrefSize(500, 40);
        
        HBox hboxaccount = new HBox();
        hboxaccount.getChildren().addAll(textaccount);
        grid.add(hboxaccount, 0, 0);
        grid.setAlignment(Pos.CENTER);

        PasswordField textpassword = new PasswordField();
        textpassword.setStyle("{-fx-text-fill:#cccccc;-fx-font-size:20;}");
        textpassword.setText("����������");
        textpassword.setOpacity(0.5);
        textpassword.setPrefSize(500, 40);
        
        
        HBox hboxpassword = new HBox();
        hboxpassword.getChildren().addAll(textpassword);
        grid.add(hboxpassword, 0, 1);

        Button buttonlogin = new Button("��  ¼");
        buttonlogin.setStyle("{-fx-font-size:20;  -fx-background-color:#62a8ea; -fx-text-fill:white; -fx-font-size:15;}");
        buttonlogin.setPrefWidth(350.0);
        buttonlogin.setPrefHeight(40.0);
        Button buttonchange = new Button("�޸�����");
        buttonchange.setStyle("{-fx-font-size:20;  -fx-background-color:#a8a8a8; -fx-text-fill:white; -fx-font-size:15;}");
        buttonchange.setPrefWidth(150.0);
        buttonchange.setPrefHeight(40.0);
        
        HBox hboxlogin = new HBox();
        hboxlogin.getChildren().addAll(buttonlogin,buttonchange);
       
        grid.add(hboxlogin, 0, 2);
        buttonlogin.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event){
                if(textaccount.getText().equals("")){
                    showMessage("�˺Ų���Ϊ�գ�");
                }
                else if(textaccount.getText().equals("admin")){
                    if(textpassword.getText().equals("")){
                        showMessage("���벻��Ϊ�գ�");
                    }
                    else {
                        SQLdormitory account = new SQLdormitory(textaccount.getText(), textpassword.getText(), true);
                        account.setSQLAccess(SQLaccess);
                        account.setSQLPassword(SQLpassword);
                        try {
                            showMessage(account.getAccess());
                            if(account.getAccess().equals("admin authencation succeed")){
                                examine exm = new examine();
                                exm.setSQLaccess(SQLaccess);
                                exm.setSQLpassword(SQLpassword);
                                primaryStage.close();
                                if(secondStage.isShowing()){
                                    secondStage.close();
                                }
                                exm.start(thirdStage);
                            }
                        } catch (SQLException sqe) {
                            showMessage("���ݿ�������⣡���������Ժ�����");
                        } catch (Exception oe) {
                            showMessage("δ֪����");
                        }
                    }
                }
                else{
                    if(textpassword.getText().equals("")){
                        showMessage("���벻��Ϊ�գ�");
                    }
                    else {
                        SQLdormitory account = new SQLdormitory(textaccount.getText(), textpassword.getText(), false);
                        account.setSQLAccess(SQLaccess);
                        account.setSQLPassword(SQLpassword);
                        try {
                            showMessage(account.getAccess());

                        }
                        catch (SQLException sqe) {
                            showMessage("���ݿ�������⣡���������Ժ�����");
                        }
                        catch (Exception oe) {
                            showMessage("δ֪����");
                        }
                    }
                }
            }
        });

        buttonchange.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                StageSetPassword stageSetPassword = new StageSetPassword();
                stageSetPassword.setSQLaccess(SQLaccess);
                stageSetPassword.setSQLpassword(SQLpassword);
                stageSetPassword.start(secondStage);
                secondStage.show();
            }
        });

        mainPane.setCenter(grid);
        mainPane.setTop(hbox);

        primaryStage.setTitle("���ҹ���ϵͳ");
        primaryStage.setScene(sceneMain);
        primaryStage.show();
    }

    public static void showMessage(String MessageText){
        Alert information = new Alert(Alert.AlertType.INFORMATION,MessageText);
        information.setTitle("����");         //���ñ���
        information.showAndWait();   //��ʾ������ͬʱ��������ȹ���
    }
}



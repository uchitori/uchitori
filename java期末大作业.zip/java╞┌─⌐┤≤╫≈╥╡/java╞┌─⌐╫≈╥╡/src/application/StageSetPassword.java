


import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.scene.control.PasswordField;

import java.awt.*;
import java.sql.SQLException;

public class StageSetPassword extends Application {
    private String SQLaccess = "root";
    private String SQLpassword = "7M14ebr5Po";
    public void setSQLpassword(String string){this.SQLpassword = string;}
    public void setSQLaccess(String string){this.SQLaccess = string;}
    public void start(Stage primaryStage){
        BorderPane BpMain = new BorderPane();
        BpMain.setPadding(new Insets(25, 25, 25, 25));

        GridPane GpInsertSets = new GridPane();
        GpInsertSets.setAlignment(Pos.CENTER);
        GpInsertSets.setHgap(10);
        GpInsertSets.setVgap(10);
        GpInsertSets.setPadding(new Insets(25, 25, 25, 25));


        Label labelAccount = new Label("�˺�");
        labelAccount.setTextFill(Color.valueOf("#62a8ea"));
        labelAccount.setStyle("-fx-font-weight: bold;");
        labelAccount.setFont(new Font(20));
        
        TextField textAccount = new TextField();
        textAccount.setStyle("{-fx-text-fill:#cccccc;-fx-font-size:15;}");
        textAccount.setOpacity(0.5);
        textAccount.setPrefSize(200,10);
        
        Label labelOldPassword = new Label("������");
        labelOldPassword.setTextFill(Color.valueOf("#62a8ea"));
        labelOldPassword.setStyle("-fx-font-weight: bold;");
        labelOldPassword.setFont(new Font(20));
        Label labelNewPassword = new Label("������");
        labelNewPassword.setTextFill(Color.valueOf("#62a8ea"));
        labelNewPassword.setStyle("-fx-font-weight: bold;");
        labelNewPassword.setFont(new Font(20));
        Label labelConfirmPassword = new Label("ȷ������");
        labelConfirmPassword.setTextFill(Color.valueOf("#62a8ea"));
        labelConfirmPassword.setStyle("-fx-font-weight: bold;");
        labelConfirmPassword.setFont(new Font(20));
        
        PasswordField psf1 = new PasswordField();
        psf1.setStyle("{-fx-text-fill:#cccccc;-fx-font-size:15;}");
        psf1.setOpacity(0.5);
        psf1.setPrefSize(200,10);
        PasswordField psf2 = new PasswordField();
        psf2.setStyle("{-fx-text-fill:#cccccc;-fx-font-size:15;}");
        psf2.setOpacity(0.5);
        psf2.setPrefSize(200,10);
        PasswordField psf3 = new PasswordField();
        psf3.setStyle("{-fx-text-fill:#cccccc;-fx-font-size:15;}");
        psf3.setOpacity(0.5);
        psf3.setPrefSize(200,10);
        
        GpInsertSets.add(labelAccount, 0, 0);
        GpInsertSets.add(textAccount, 1, 0);
        GpInsertSets.add(labelOldPassword, 0, 1);
        GpInsertSets.add(psf1, 1, 1);
        GpInsertSets.add(labelNewPassword, 0, 2);
        GpInsertSets.add(psf2, 1, 2);
        GpInsertSets.add(labelConfirmPassword, 0, 3);
        GpInsertSets.add(psf3, 1, 3);

        HBox hboxBtns = new HBox();
        hboxBtns.setAlignment(Pos.CENTER);
        hboxBtns.setSpacing(50);
        Button btnConfirm = new Button("ȷ��");
        btnConfirm.setStyle("{-fx-font-size:20;  -fx-background-color:#62a8ea; -fx-text-fill:white; -fx-font-size:15;}");
        btnConfirm.setPrefWidth(100.0);
        btnConfirm.setPrefHeight(10.0);
        
        Button btnCancel = new Button("ȡ��");
        btnCancel.setStyle("{-fx-font-size:20;  -fx-background-color:#62a8ea; -fx-text-fill:white; -fx-font-size:15;}");
        btnCancel.setPrefWidth(100.0);
        btnCancel.setPrefHeight(10.0);
        
        hboxBtns.getChildren().addAll(btnConfirm, btnCancel);
        btnConfirm.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event){
                try {
                    if (psf2.getText().equals(psf3.getText())) {
                        SQLdormitory acce = new SQLdormitory(textAccount.getText(), psf1.getText(), false);
                        acce.setSQLAccess(SQLaccess);
                        acce.setSQLPassword(SQLpassword);
                        if (textAccount.getText().equals("admin")) {
                            acce.setIsAdmin(true);
                        }
                        showMessage(acce.setPassword(psf2.getText()));
                    }
                    else{
                        showMessage("���������벻ͬ��");
                        psf2.setText("");
                        psf3.setText("");
                    }
                }
                catch (SQLException se){
                    showMessage("SQL���ݿ����");
                }
                catch (Exception e){
                    showMessage("δ֪����");
                }
            }
        });

        btnCancel.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                primaryStage.close();
            }
        });

        BpMain.setCenter(GpInsertSets);
        BpMain.setBottom(hboxBtns);

        Scene mainScene = new Scene(BpMain, 400, 300);
        primaryStage.setTitle("�޸�����");
        primaryStage.setScene(mainScene);
        primaryStage.show();
    }

    public static void showMessage(String MessageText){
        Alert information = new Alert(Alert.AlertType.INFORMATION,MessageText);
        information.setTitle("����");         //���ñ���
        information.showAndWait();   //��ʾ������ͬʱ��������ȹ���
    }

    public static void main(String[] args){
        launch(args);
    }

}


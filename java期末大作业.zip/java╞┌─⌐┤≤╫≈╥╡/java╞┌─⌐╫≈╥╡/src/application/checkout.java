


import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.util.Optional;

public class checkout extends Application{
        private String SQLpassword = "7M14ebr5Po";
        private String SQLaccess = "root";


        private String RoomNum = "";
        public void setSQLaccess(String string){this.SQLaccess = string;}
        public void setSQLpassword(String string){this.SQLpassword = string;}
        public void setRoomNum(String string){this.RoomNum = string;}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub
            SQLdormitory sqLdormitory = new SQLdormitory();
            sqLdormitory.setSQLAccess(SQLaccess);
            sqLdormitory.setSQLPassword(SQLpassword);
            String[][] info = sqLdormitory.getInformation("roomId", RoomNum);
            boolean[] bedstat = new boolean[4];
            int restbednum = 4;
            for(int i = 0; i < 4; i++){
                    if(info[0][i + 1].equals("无")){
                            bedstat[i] = false;
                    }
                    else{
                            bedstat[i] = true;
                            restbednum--;
                    }
            }
		
		BorderPane mainPane = new BorderPane();
        mainPane.setPadding(new Insets(25, 25, 25, 25));

        BorderPane centerPane = new BorderPane();
        mainPane.setPadding(new Insets(25, 25, 25, 25));

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(25, 25, 25,25));
        grid.setVgap(5);
        grid.setHgap(5);
        grid.setAlignment(Pos.CENTER);

        Scene sceneMain = new Scene(mainPane,400,510);
        
        Label labeltitle = new Label("退 房 登 记");
        labeltitle.setAlignment(Pos.CENTER);
	    labeltitle.setTextFill(Color.valueOf("#62a8ea"));
	    labeltitle.setStyle("-fx-font-weight: bold");
	    labeltitle.setFont(new Font(30));
	    
	    HBox hbox = new HBox();
	    hbox.setPadding(new Insets(25, 25, 25, 25));
	    hbox.setAlignment(Pos.CENTER);
	    hbox.getChildren().addAll(labeltitle);
        
        HBox hbsureturn = new HBox();
        hbsureturn.setAlignment(Pos.CENTER);
        Button returnbutton = new Button("返回主页");
        returnbutton.setStyle("-fx-font-size:20;  -fx-background-color:#62a8ea; -fx-text-fill:white; -fx-font-size:15;");
        returnbutton.setPrefWidth(245.0);
        returnbutton.setPrefHeight(10.0);
        hbsureturn.getChildren().add(returnbutton);
        centerPane.setBottom(hbsureturn);
        
        HBox hbchoosefree = new HBox();
        hbchoosefree.setSpacing(10);
        Label labelchoose = new Label("您选择的寝室是：" + RoomNum);
        labelchoose.setTextFill(Color.valueOf("#62a8ea"));
        labelchoose.setStyle("-fx-font-weight: bold;");
        labelchoose.setFont(new Font(10));
        Label labelfree = new Label("寝室空余床位数：" + restbednum);
        labelfree.setTextFill(Color.valueOf("#62a8ea"));
        labelfree.setStyle("-fx-font-weight: bold;");
        labelfree.setFont(new Font(10));
        hbchoosefree.getChildren().addAll(labelchoose,labelfree);
        hbchoosefree.setAlignment(Pos.CENTER);
        
        Button balconybutton = new Button("阳台");
        balconybutton.setStyle("-fx-background-color:#62a8ea;-fx-font-size:20;-fx-text-fill:white;");
        balconybutton.setPrefWidth(165.0);
        balconybutton.setMaxHeight(200.0);
        balconybutton.setPrefHeight(60);
            Button button01 = new Button("01\n号\n床");
            button01.setStyle("-fx-background-color:white;-fx-font-size:20;");
            button01.setPrefWidth(80.0);
            button01.setPrefHeight(120.0);
            if(!bedstat[0]){
                    button01.setStyle("-fx-background-color: yellow;-fx-border-color: yellow;-fx-border-width: 3");
            }
            else{
                    button01.setStyle("-fx-background-color: red;-fx-border-color: red;-fx-border-width: 3");
            }
            Button button02 = new Button("02\n号\n床");
            button02.setStyle("-fx-background-color:white;-fx-font-size:20;");
            button02.setPrefWidth(80.0);
            button02.setPrefHeight(120.0);
            if(!bedstat[1]){
                    button02.setStyle("-fx-background-color: yellow;-fx-border-color: yellow;-fx-border-width: 3");
            }
            else {
                    button02.setStyle("-fx-background-color: red;-fx-border-color: red;-fx-border-width: 3");
            }
            Button button03 = new Button("03\n号\n床");
            button03.setStyle("-fx-background-color:white;-fx-font-size:20;");
            button03.setPrefWidth(80.0);
            button03.setPrefHeight(120.0);
            if(!bedstat[2]){
                    button03.setStyle("-fx-background-color: yellow;-fx-border-color: yellow;-fx-border-width: 3");
            }
            else {
                    button03.setStyle("-fx-background-color: red;-fx-border-color: red;-fx-border-width: 3");
            }
            Button button04 = new Button("04\n号\n床");
            button04.setStyle("-fx-background-color:white;-fx-font-size:20;");
            button04.setPrefWidth(80.0);
            button04.setPrefHeight(120.0);
            if(!bedstat[3]){
                    button04.setStyle("-fx-background-color: yellow;-fx-border-color: yellow;-fx-border-width: 3");
            }
            else {
                    button04.setStyle("-fx-background-color: red;-fx-border-color: red;-fx-border-width: 3");
            }
            button01.setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {
                            if(!bedstat[0]){
                                    showMessage("该床位没有人！");
                            }
                            else{
                                    Alert alert = new Alert(Alert.AlertType.CONFIRMATION,"确认退房吗？");
                                    alert.setTitle("确认操作");
                                    Optional<ButtonType> result = alert.showAndWait();
                                    if(result.isPresent() && result.get() == ButtonType.OK){
                                            showMessage(sqLdormitory.Signout(RoomNum, 1));
                                            if(sqLdormitory.Signout(RoomNum, 1).equals("退房成功！")){
                                                    try {
                                                            examine exa = new examine();
                                                            exa.setSQLpassword(SQLpassword);
                                                            exa.setSQLaccess(SQLaccess);
                                                            Stage stage = new Stage();
                                                            exa.start(stage);
                                                            primaryStage.close();
                                                    }
                                                    catch (Exception e){
                                                            showMessage("未知错误!");
                                                    }
                                            }
                                    }
                            }
                    }
            });
            button02.setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {
                            if(!bedstat[1]){
                                    showMessage("该床位没有人！");
                            }
                            else{
                                    Alert alert = new Alert(Alert.AlertType.CONFIRMATION,"确认退房吗？");
                                    alert.setTitle("确认操作");
                                    Optional<ButtonType> result = alert.showAndWait();
                                    if(result.isPresent() && result.get() == ButtonType.OK){
                                            showMessage(sqLdormitory.Signout(RoomNum, 2));
                                            if(sqLdormitory.Signout(RoomNum, 2).equals("退房成功！")){
                                                    try {
                                                            examine exa = new examine();
                                                            exa.setSQLaccess(SQLaccess);
                                                            exa.setSQLpassword(SQLpassword);
                                                            Stage stage = new Stage();
                                                            exa.start(stage);
                                                            primaryStage.close();
                                                    }
                                                    catch (Exception e){
                                                            showMessage("未知错误!");
                                                    }
                                            }
                                    }
                            }
                    }
            });
            button03.setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {
                            if(!bedstat[2]){
                                    showMessage("该床位没有人！");
                            }
                            else{
                                    Alert alert = new Alert(Alert.AlertType.CONFIRMATION,"确认退房吗？");
                                    alert.setTitle("确认操作");
                                    Optional<ButtonType> result = alert.showAndWait();
                                    if(result.isPresent() && result.get() == ButtonType.OK){
                                            showMessage(sqLdormitory.Signout(RoomNum, 3));
                                            if(sqLdormitory.Signout(RoomNum, 3).equals("退房成功！")){
                                                    try {
                                                            examine exa = new examine();
                                                            exa.setSQLpassword(SQLpassword);
                                                            exa.setSQLaccess(SQLaccess);
                                                            Stage stage = new Stage();
                                                            exa.start(stage);
                                                            primaryStage.close();
                                                    }
                                                    catch (Exception e){
                                                            showMessage("未知错误!");
                                                    }
                                            }
                                    }
                            }
                    }
            });
            button04.setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {
                            if(!bedstat[3]){
                                    showMessage("该床位没有人！");
                            }
                            else{
                                    Alert alert = new Alert(Alert.AlertType.CONFIRMATION,"确认退房吗？");
                                    alert.setTitle("确认操作");
                                    Optional<ButtonType> result = alert.showAndWait();
                                    if(result.isPresent() && result.get() == ButtonType.OK){
                                            showMessage(sqLdormitory.Signout(RoomNum, 4));
                                            if(sqLdormitory.Signout(RoomNum, 4).equals("退房成功！")){
                                                    try {
                                                            examine exa = new examine();
                                                            exa.setSQLaccess(SQLaccess);
                                                            exa.setSQLpassword(SQLpassword);
                                                            Stage stage = new Stage();
                                                            exa.start(stage);
                                                            primaryStage.close();
                                                    }
                                                    catch (Exception e){
                                                            showMessage("未知错误!");
                                                    }
                                            }
                                    }
                            }
                    }
            });
        Button buttonyellow = new Button();
        buttonyellow.setStyle("-fx-background-color:yellow;");
        Button buttonred = new Button();
        buttonred.setStyle("-fx-background-color:red;");
        Label labelno = new Label("未使用");
        Label labelyes = new Label("已使用");
        HBox hbpic1 = new HBox();
        HBox hbpic2 = new HBox();
        HBox hbpic3 = new HBox();
        HBox hbpic4 = new HBox();
        hbpic1.getChildren().addAll(button01,button02);
        hbpic1.setSpacing(5);
        hbpic2.getChildren().addAll(button03,button04);
        hbpic2.setSpacing(5);
        hbpic3.getChildren().addAll(buttonyellow,labelno);
        hbpic3.setSpacing(5);
        hbpic4.getChildren().addAll(buttonred,labelyes);
        hbpic4.setSpacing(5);
        GridPane grid2 = new GridPane();
        grid2.setVgap(6);
        grid2.setAlignment(Pos.CENTER);
        grid2.add(balconybutton, 0, 0);
        grid2.add(hbpic1, 0, 1);
        grid2.add(hbpic2, 0, 2);
        
        VBox vbAttention = new VBox();
        vbAttention.setSpacing(5);
        vbAttention.getChildren().addAll(hbpic3,hbpic4);
        
        VBox chartInfo =new VBox();
        Label labelpicture = new Label("学\n生\n寝\n室\n示\n意\n图");
        chartInfo.getChildren().addAll(labelpicture,vbAttention);
        chartInfo.setSpacing(110);
        chartInfo.setAlignment(Pos.CENTER);
        
        HBox hboxxx = new HBox();
        hboxxx.getChildren().addAll(grid2,chartInfo);
        hboxxx.setSpacing(30);
        hboxxx.setAlignment(Pos.CENTER);
        
        
        centerPane.setCenter(hboxxx);
        BorderPane.setAlignment(hboxxx, Pos.CENTER);

        mainPane.setTop(hbox);
        mainPane.setCenter(centerPane);
        mainPane.setBottom(hbchoosefree);
        
     
        primaryStage.setTitle("寝室管理系统");
        primaryStage.setScene(sceneMain);
        primaryStage.show();
        
        
	}
        public static void showMessage(String MessageText){
                Alert information = new Alert(Alert.AlertType.INFORMATION,MessageText);
                information.setTitle("警告");         //设置标题
                information.showAndWait();   //显示弹窗，同时后续代码等挂起
        }
}


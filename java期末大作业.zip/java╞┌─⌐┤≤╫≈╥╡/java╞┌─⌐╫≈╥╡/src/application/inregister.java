

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class inregister extends Application{
        private String RoomNum = "";
    private String SQLaccess = "root";
    private String SQLpassword = "7M14ebr5Po";
    public void setSQLpassword(String string){this.SQLpassword = string;}
    public void setSQLaccess(String string){this.SQLaccess = string;}

        public void setRoomNum(String inString){this.RoomNum = inString;}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub
            SQLdormitory sqLdormitory = new SQLdormitory();
            sqLdormitory.setSQLPassword(SQLpassword);
            sqLdormitory.setSQLAccess(SQLaccess);
            String[][] info = sqLdormitory.getInformation("roomId", RoomNum);
            boolean[] bedstat = new boolean[4];
            int restbednum = 4;
            for(int i = 0; i < 4; i++){
                    if(info[0][i + 1].equals("��")){
                            bedstat[i] = false;
                    }
                    else{
                            bedstat[i] = true;
                            restbednum--;
                    }
            }
		
		BorderPane mainPane = new BorderPane();
        mainPane.setPadding(new Insets(25, 25, 25, 25));
        

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(25, 0, 25,25 ));
        grid.setVgap(10);
        grid.setHgap(10);
        grid.setAlignment(Pos.CENTER);

        Scene sceneMain = new Scene(mainPane,700,500);
        
        Label labeltitle = new Label("�� ס �� ��");
	    labeltitle.setAlignment(Pos.CENTER);
	    labeltitle.setTextFill(Color.valueOf("#62a8ea"));
	    labeltitle.setStyle("-fx-font-weight: bold");
	    labeltitle.setFont(new Font(30));
	    
	    HBox hbox = new HBox();
	    hbox.setPadding(new Insets(25, 25, 25, 25));
	    hbox.setAlignment(Pos.CENTER);
	    hbox.getChildren().addAll(labeltitle);
        
        HBox hbnumber= new HBox();
        Label labelnumber = new Label("ѧ�� ");
        labelnumber.setTextFill(Color.valueOf("#62a8ea"));
        labelnumber.setStyle("-fx-font-weight: bold;");
        labelnumber.setFont(new Font(20));
        TextField textnumber = new TextField();
        textnumber.setStyle("{-fx-text-fill:#cccccc;-fx-font-size:15;}");
        textnumber.setOpacity(0.5);
        textnumber.setPrefSize(200,10);
        hbnumber.getChildren().addAll(labelnumber,textnumber);
        
        HBox hbname = new HBox();
        Label labelname = new Label("���� ");
        labelname.setTextFill(Color.valueOf("#62a8ea"));
   	    labelname.setStyle("-fx-font-weight: bold;");
   	    labelname.setFont(new Font(20));
        TextField textname = new TextField();
        textname.setStyle("{-fx-text-fill:#cccccc;-fx-font-size:15;}");
        textname.setOpacity(0.5);
        textname.setPrefSize(200,10);
        hbname.getChildren().addAll(labelname,textname);
        
        HBox hbinstitution= new HBox();
        Label labelinstitution = new Label("ѧԺ ");
        labelinstitution.setTextFill(Color.valueOf("#62a8ea"));
   	    labelinstitution.setStyle("-fx-font-weight: bold;");
   	    labelinstitution.setFont(new Font(20));
   	    
        TextField textinstitution = new TextField();
        textinstitution.setStyle("{-fx-text-fill:#cccccc;-fx-font-size:15;}");
        textinstitution.setOpacity(0.5);
        textinstitution.setPrefSize(200,10);
        hbinstitution.getChildren().addAll(labelinstitution,textinstitution);
        
        HBox hbdepart= new HBox();
        Label labeldepart = new Label("ϵ�� ");
        labeldepart.setTextFill(Color.valueOf("#62a8ea"));
        labeldepart.setStyle("-fx-font-weight: bold;");
        labeldepart.setFont(new Font(20));
        TextField textdepart = new TextField();
        textdepart.setStyle("{-fx-text-fill:#cccccc;-fx-font-size:15;}");
        textdepart.setOpacity(0.5);
        textdepart.setPrefSize(200,10);
        hbdepart.getChildren().addAll(labeldepart,textdepart);
        
        HBox hbclass= new HBox();
        Label labelclass = new Label("�༶ ");
        labelclass.setTextFill(Color.valueOf("#62a8ea"));
        labelclass.setStyle("-fx-font-weight: bold;");
        labelclass.setFont(new Font(20));
        TextField textclass = new TextField();
        textclass.setStyle("{-fx-text-fill:#cccccc;-fx-font-size:15;}");
        textclass.setOpacity(0.5);
        textclass.setPrefSize(200,10);
        hbclass.getChildren().addAll(labelclass,textclass);
        
        HBox hbbed= new HBox();
        Label labelbed = new Label("���� ");
        labelbed.setTextFill(Color.valueOf("#62a8ea"));
        labelbed.setStyle("-fx-font-weight: bold;");
        labelbed.setFont(new Font(20));
        TextField textbed = new TextField();
        textbed.setStyle("{-fx-text-fill:#cccccc;-fx-font-size:15;}");
        textbed.setOpacity(0.5);
        textbed.setPrefSize(200,10);
        hbbed.getChildren().addAll(labelbed,textbed);
        
        HBox hbsureturn = new HBox();
        Button surebutton = new Button("ȷ����ס");
        surebutton.setStyle("{-fx-font-size:20;  -fx-background-color:#62a8ea; -fx-text-fill:white; -fx-font-size:15;}");
        surebutton.setPrefWidth(245.0);
        surebutton.setPrefHeight(10.0);
        

        hbsureturn.getChildren().addAll(surebutton);
        
        HBox hbreturnturn = new HBox();
        Button returnbutton = new Button("������ҳ");
        returnbutton.setStyle("{-fx-font-size:20;  -fx-background-color:#62a8ea; -fx-text-fill:white; -fx-font-size:15;}");
        returnbutton.setPrefWidth(245.0);
        returnbutton.setPrefHeight(10.0);
        hbreturnturn.getChildren().addAll(returnbutton);
        
        grid.add(hbnumber, 0, 0);
        grid.add(hbname, 0, 1);
        grid.add(hbinstitution, 0, 2);
        grid.add(hbdepart, 0, 3);
        grid.add(hbclass, 0, 4);
        grid.add(hbbed, 0, 5);
        grid.add(hbsureturn, 0, 6);
        grid.add(hbreturnturn, 0, 7);
        
        HBox hbchoosefree = new HBox();
        hbchoosefree.setSpacing(10);
        Label labelchoose = new Label("        ��ѡ��������ǣ�" + RoomNum);
        labelchoose.setTextFill(Color.valueOf("#62a8ea"));
        labelchoose.setStyle("-fx-font-weight: bold;");
        labelchoose.setFont(new Font(10));
        Label labelfree = new Label("���ҿ��ലλ����" + restbednum);
        labelfree.setTextFill(Color.valueOf("#62a8ea"));
        labelfree.setStyle("-fx-font-weight: bold;");
        labelfree.setFont(new Font(10));
        hbchoosefree.getChildren().addAll(labelchoose,labelfree);
        
        Button balconybutton = new Button("��̨");
        balconybutton.setStyle("-fx-background-color:#62a8ea;-fx-font-size:20;-fx-text-fill:white;");
        balconybutton.setPrefWidth(165.0);
        balconybutton.setMaxHeight(200.0);
        balconybutton.setPrefHeight(60);
        Button button01 = new Button("01\n��\n��");
        button01.setStyle("-fx-background-color:white;-fx-font-size:20;");
        button01.setPrefWidth(80.0);
        button01.setPrefHeight(120.0);
        if(!bedstat[0]){
                button01.setStyle("-fx-background-color: yellow;-fx-border-color: yellow;-fx-border-width: 3");
        }
        else{
                button01.setStyle("-fx-background-color: red;-fx-border-color: red;-fx-border-width: 3");
        }
        Button button02 = new Button("02\n��\n��");
        button02.setStyle("-fx-background-color:white;-fx-font-size:20;");
        button02.setPrefWidth(80.0);
        button02.setPrefHeight(120.0);
        if(!bedstat[1]){
                button02.setStyle("-fx-background-color: yellow;-fx-border-color: yellow;-fx-border-width: 3");
        }
        else {
                button02.setStyle("-fx-background-color: red;-fx-border-color: red;-fx-border-width: 3");
        }
        Button button03 = new Button("03\n��\n��");
        button03.setStyle("-fx-background-color:white;-fx-font-size:20;");
        button03.setPrefWidth(80.0);
        button03.setPrefHeight(120.0);
        if(!bedstat[2]){
                button03.setStyle("-fx-background-color: yellow;-fx-border-color: yellow;-fx-border-width: 3");
        }
        else {
                button03.setStyle("-fx-background-color: red;-fx-border-color: red;-fx-border-width: 3");
        }
        Button button04 = new Button("04\n��\n��");
        button04.setStyle("-fx-background-color:white;-fx-font-size:20;");
        button04.setPrefWidth(80.0);
        button04.setPrefHeight(120.0);
        if(!bedstat[3]){
                button04.setStyle("-fx-background-color: yellow;-fx-border-color: yellow;-fx-border-width: 3");
        }
        else {
                button04.setStyle("-fx-background-color: red;-fx-border-color: red;-fx-border-width: 3");
        }
        button01.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                        if(bedstat[0]){
                                showMessage("�ô�λ��������ס��");
                        }
                        else{
                                textbed.setText("1");
                        }
                }
        });

        button02.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                        if(bedstat[1]){
                                showMessage("�ô�λ��������ס��");
                        }
                        else {
                                textbed.setText("2");
                        }
                }
        });

            button03.setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {
                            if(bedstat[2]){
                                    showMessage("�ô�λ��������ס��");
                            }
                            else {
                                    textbed.setText("3");
                            }
                    }
            });

            button04.setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {
                            if(bedstat[3]){
                                    showMessage("�ô�λ��������ס��");
                            }
                            else {
                                    textbed.setText("4");
                            }
                    }
            });

            surebutton.setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {
                            if(textbed.getText().equals("") || textclass.getText().equals("") || textname.getText().equals("") || textdepart.getText().equals("") || textnumber.getText().equals("") && textinstitution.getText().equals("")){
                                    showMessage("���������Ϣ������");
                            }
                            else if(!sqLdormitory.studentIdentifier(textnumber.getText(), textname.getText(), textinstitution.getText(), textdepart.getText(), textclass.getText())){
                                    showMessage("���������Ϣ����");
                            }
                            else{
                                    showMessage(sqLdormitory.Signin(RoomNum,Integer. valueOf(textbed.getText()), textnumber.getText()));
                                    if(sqLdormitory.Signin(RoomNum, Integer.valueOf(textbed.getText()), textnumber.getText()).equals("��λ�޸ĳɹ���")){
                                            try {
                                                    primaryStage.close();
                                                    examine exa = new examine();
                                                    exa.setSQLpassword(SQLpassword);
                                                    exa.setSQLaccess(SQLaccess);
                                                    Stage secondstage = new Stage();
                                                    exa.start(secondstage);
                                            }
                                            catch (Exception e){
                                                    showMessage("���ִ���");
                                            }
                                    }
                            }
                    }
            });

            returnbutton.setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {
                            try {
                                    primaryStage.close();
                                    examine exa = new examine();
                                    exa.setSQLaccess(SQLaccess);
                                    exa.setSQLpassword(SQLpassword);
                                    Stage stage = new Stage();
                                    exa.start(stage);
                            }
                            catch (Exception e){
                                    showMessage("���ִ���");
                            }
                    }
            });
        Button buttonyellow = new Button();
        buttonyellow.setStyle("-fx-background-color:yellow;");
        Button buttonred = new Button();
        buttonred.setStyle("-fx-background-color:red;");
        Label labelno = new Label("δʹ��");
        Label labelyes = new Label("��ʹ��");
        HBox hbpic1 = new HBox();
        HBox hbpic2 = new HBox();
        HBox hbpic3 = new HBox();
        HBox hbpic4 = new HBox();
        hbpic1.getChildren().addAll(button01,button02);
        hbpic1.setSpacing(5);
        hbpic2.getChildren().addAll(button03,button04);
        hbpic2.setSpacing(5);
        hbpic3.getChildren().addAll(buttonyellow,labelno);
        hbpic3.setSpacing(5);
        hbpic4.getChildren().addAll(buttonred,labelyes);
        hbpic4.setSpacing(5);
        GridPane grid2 = new GridPane();
        grid2.setVgap(6);
        grid2.setAlignment(Pos.CENTER);
        grid2.add(balconybutton, 0, 0);
        grid2.add(hbpic1, 0, 1);
        grid2.add(hbpic2, 0, 2);
        
        
        VBox vbAttention = new VBox();
        vbAttention.setSpacing(5);
        vbAttention.getChildren().addAll(hbpic3,hbpic4);
        
        VBox chartInfo =new VBox();
        Label labelpicture = new Label("ѧ\n��\n��\n��\nʾ\n��\nͼ");
        chartInfo.getChildren().addAll(labelpicture,vbAttention);
        chartInfo.setSpacing(110);
        chartInfo.setAlignment(Pos.CENTER);
        
        HBox hboxxx = new HBox();
        hboxxx.getChildren().addAll(grid2,chartInfo);
        hboxxx.setSpacing(30);
        
        HBox hboxx= new HBox();
        hboxx.getChildren().addAll(grid,hboxxx);
        hboxx.setSpacing(30);
        
        mainPane.setTop(hbox);
        mainPane.setCenter(hboxx);
        mainPane.setBottom(hbchoosefree);
        
     
        primaryStage.setTitle("���ҹ���ϵͳ");
        primaryStage.setScene(sceneMain);
        primaryStage.show();
        
        
        
	}
        public static void showMessage(String MessageText){
                Alert information = new Alert(Alert.AlertType.INFORMATION,MessageText);
                information.setTitle("����");         //���ñ���
                information.showAndWait();   //��ʾ������ͬʱ��������ȹ���
        }
}


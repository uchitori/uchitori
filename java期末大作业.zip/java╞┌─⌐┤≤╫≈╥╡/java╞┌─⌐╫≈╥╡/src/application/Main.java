

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class Main extends Application {
    private String SQLaccess = "root";
    private String SQLpassword = "7M14ebr5Po";
    public void setSQLpassword(String string){this.SQLpassword = string;}
    public void setSQLaccess(String string){this.SQLaccess = string;}

    @Override
    public void start(Stage primaryStage) throws Exception{
        Stage secondaryStage = new Stage();

        BorderPane BpSetSQLInformation = new BorderPane();
        BpSetSQLInformation.setPadding(new Insets(25, 25, 25, 25));
        GridPane gpsets = new GridPane();
        gpsets.setPadding(new Insets(25, 25, 25, 25));
        gpsets.setAlignment(Pos.CENTER);
        gpsets.setVgap(5);
        gpsets.setHgap(5);

        Label labelSetSQLAccess = new Label("本机MYSql账户");
        labelSetSQLAccess.setTextFill(Color.valueOf("#62a8ea"));
        labelSetSQLAccess.setStyle("-fx-font-weight: bold;");
        labelSetSQLAccess.setFont(new Font(20));
        Label labelSetSQLPassword = new Label("本机MYSql密码");
        labelSetSQLPassword.setTextFill(Color.valueOf("#62a8ea"));
        labelSetSQLPassword.setStyle("-fx-font-weight: bold;");
        labelSetSQLPassword.setFont(new Font(20));
        TextField textSQLAccess = new TextField();
        textSQLAccess.setStyle("-fx-text-fill:#cccccc;-fx-font-size:20;");
        textSQLAccess.setOpacity(0.5);
        textSQLAccess.setPrefSize(200, 40);
        TextField textSQLPassword = new TextField();
        textSQLPassword.setStyle("-fx-text-fill:#cccccc;-fx-font-size:20;");
        textSQLPassword.setOpacity(0.5);
        textSQLPassword.setPrefSize(200, 40);

        gpsets.add(labelSetSQLAccess, 0, 0);
        gpsets.add(labelSetSQLPassword, 0, 1);
        gpsets.add(textSQLAccess, 1, 0);
        gpsets.add(textSQLPassword, 1, 1);

        SQLdormitory sqltester = new SQLdormitory();
        textSQLAccess.setText(sqltester.getSQLAccess());
        textSQLPassword.setText(sqltester.getSQLPassword());

        HBox hboxbtnsets = new HBox();
        hboxbtnsets.setPadding(new Insets(0, 25, 25, 25));
        hboxbtnsets.setSpacing(30);
        hboxbtnsets.setAlignment(Pos.CENTER);
        Button btnconfirm = new Button("确认修改");
        btnconfirm.setStyle("-fx-font-size:20;  -fx-background-color:#62a8ea; -fx-text-fill:white; -fx-font-size:15;");
        btnconfirm.setPrefWidth(150.0);
        btnconfirm.setPrefHeight(30.0);
        Button btntest = new Button("测试连接");
        btntest.setStyle("-fx-font-size:20;  -fx-background-color:#62a8ea; -fx-text-fill:white; -fx-font-size:15;");
        btntest.setPrefWidth(150.0);
        btntest.setPrefHeight(30.0);
        btnconfirm.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                sqltester.setSQLAccess(textSQLAccess.getText());
                sqltester.setSQLPassword(textSQLPassword.getText());
                if(sqltester.testConnection()){
                    showMessage("数据库连接成功！");
                    primaryStage.close();
                    login stageLogin = new login();
                    stageLogin.setSQLaccess(textSQLAccess.getText());
                    stageLogin.setSQLpassword(textSQLPassword.getText());
                    stageLogin.start(secondaryStage);
                }
                else{
                    showMessage("数据库连接不成功！请尝试修改密码");
                }
            }
        });
        btntest.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                sqltester.setSQLAccess(textSQLAccess.getText());
                sqltester.setSQLPassword(textSQLPassword.getText());
                if(sqltester.testConnection()){
                    showMessage("数据库连接成功！");
                }
                else{
                    showMessage("数据库连接不成功！请尝试修改密码");
                }
            }
        });
        hboxbtnsets.getChildren().addAll(btnconfirm, btntest);

        BpSetSQLInformation.setCenter(gpsets);
        BpSetSQLInformation.setBottom(hboxbtnsets);

        primaryStage.setTitle("请设置本机访问密码");
        primaryStage.setScene(new Scene(BpSetSQLInformation, 500, 250));
        primaryStage.show();
    }


    public static void main(String[] args) {
        launch(args);
    }

    public static void showMessage(String MessageText){
        Alert information = new Alert(Alert.AlertType.INFORMATION,MessageText);
        information.setTitle("警告");         //设置标题
        information.showAndWait();   //显示弹窗，同时后续代码等挂起
    }
}



